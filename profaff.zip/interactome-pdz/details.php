<!DOCTYPE html>
<?php

require_once('../PDZconnect.php');
?>
<style>

.centeredhalf{width:100%}
@media (min-width:1000px){.centeredhalf{width:75%}}
@media (min-width:1600px){.centeredhalf{width:50%}}


</style>
<html>
	<?php
	session_start();
	if(isset($_POST['SubmitButton'])){ //check if form was submitted
	  $input = $_POST["PBM"]; //get input text
	}    
	?>
	<head>
		<title>PDZ-PBM interactome</title>
		<link rel="stylesheet" href="../assets/header-search.css">
		<script>
			var coll = document.getElementsByClassName("collapsible");
			var i;

			for (i = 0; i < coll.length; i++) {
			  coll[i].addEventListener("click", function() {
			    this.classList.toggle("active");
			    var content = this.nextElementSibling;
			    if (content.style.display === "block") {
			      content.style.display = "none";
			    } else {
			      content.style.display = "block";
			    }
			  });
			}
		</script>
	</head>

	<body>

		<!-- THIS PART makes the connection to the mysql server -->


		<!-- THIS PART GENERATES THE MENU BAR WITH THE SEARCH FIELD -->
		<header class="header-search">
			<div class="header-limiter">
				<h1><a href="../index.php"><img src="../assets/profaff.png"  width='210' height='30' /></a></h1>
				<nav>
					<a href="PDZPBM.php">PDZ/PBM Interactome</a>
					<a href="method.php">Method</a>
					<a href="searchPBM.php">Explore</a>

				</nav>







			</div>
		</header>

		<!-- THIS PART is about general info about the selected entry -->
<p></p>		
<center>

<?php

$PDZ="RADIL";
$PBM="ASIC3";

$PDZ = $_GET["pdz"]; 

$PBM = $_GET["pbm"]; 

$pkds = array();
$pkdsnoempty =array();
$methods = array();

$details = 'SELECT PDZ, PBM, FP_aver_uM, FP_stdev_uM, DAPF_BI_aver, DAPF_BI_stdev, DAPF_n, DAPF_BI_norm_aver, DAPF_BI_norm_stdev, DAPF_PEP_uM, DAPF_PEPconv_uM, DAPF_neglogKd, CALIP_BI_aver, CALIP_BI_stdev, CALIP_n, CALIP_PEP_uM, CALIP_PEPconv_uM, CALIP_neglogKd, CALIP_METHOD, SAPF_BI_aver, SAPF_BI_std, SAPF_n, SAPF_BI_norm_aver, SAPF_BI_norm_std, SAPF_PEP_uM, SAPF_PEPconv_uM, SAPF_neglogKd, COMP_neglogKd, COMP_method from PDZPBM WHERE PBM = "'.$PBM.'" AND PDZ = "'.$PDZ.'"  AND STATUS = "PUBL" ';

$result = $conn->query($details);

while($row = $result->fetch_assoc()) {

	echo "<b>Details of the interaction between the PBM of ".$PBM." and the ".$PDZ." domain </b><br>";
	
	if (!empty($row['FP_aver_uM'])) {
	echo "<br><img src='./lights/FP.png' width='20' height='20'>";
	echo "<br><b>Summary of Fluorescent polarization assay</b><br>";


	if (file_exists("./FP/".$PDZ."/".$PBM.".png")){
		echo '<center><img src="FP/'.$PDZ.'/'.$PBM.'.png" width="320" height="240"></center>';
	} else{
		echo "<br><i style='color:red'>!!! Figure is missing. Please send a screenshot/link to the developers. !!!</i><br><br>";
	}

	if ($row['FP_aver_uM'] > 0){
		echo "The dissociation constand deduced from FP is ". round($row['FP_aver_uM'], 4)." &micro;M with a standard deviation of ".round($row['FP_stdev_uM'], 4)." &micro;M<br>";
		echo "FP was performed in triplicates.<br>";
		$pkds[]=-log10($row['FP_aver_uM']/1000000);
		$pkdsnoempty[]=-log10($row['FP_aver_uM']/1000000);
		$methods[]="FP";
		
		
	} else {
		echo "No detectable binding in FP<br>";
		$pkds[]=3.5;
		$methods[]="FP";
	}
	} else {
	echo "<br><img src='./lights/NM.png' width='20' height='20'>";
	echo "<br><b>No FP measurement is available.</b> <br>";
	}

	if (!empty($row['DAPF_BI_aver'])) {
	echo "<br><img src='./lights/DAPF.png' width='20' height='20'>";
	echo "<br><b>Summary of holdup measurement with double affinity purified PDZ protein coupled with fluorescent readout (DAPF)</b><br>";
	echo round($row['DAPF_n'])." DAPF experiments were performed<br>";
	if ($row['DAPF_n'] > 1){
		echo "The raw binding intensity is ". round($row['DAPF_BI_aver'], 2)." BI with a standard deviation of ".round($row['DAPF_BI_stdev'], 2)." BI<br>";
		echo "After correction to PDZ inactivity, the binding intensity is ". round($row['DAPF_BI_norm_aver'], 2)." BI with a standard deviation of ".round($row['DAPF_BI_norm_stdev'], 2)." BI<br>";
	} else {
		echo "The raw binding intensity is ". round($row['DAPF_BI_aver'], 2)." BI<br>";
		echo "After correction to PDZ inactivity, the binding intensity is ". round($row['DAPF_BI_norm_aver'], 2)." BI<br>";
	}
	echo "Peptide concentration for conversion is ".round($row['DAPF_PEPconv_uM'], 1)." &micro;M<br>";
	$thresholdDAPF= round(-log10((($row['DAPF_PEPconv_uM']/0.05)-4-$row['DAPF_PEPconv_uM']+(0.05*4))/1000000),2);
	echo "At this peptide concentration, the detection threshold at 0.05 BI is: ".$thresholdDAPF." p<i>K</i><sub>d</sub><br>";

	if ($row['DAPF_neglogKd'] > 0){
		$pkds[]=$row['DAPF_neglogKd'];
		$pkdsnoempty[]=$row['DAPF_neglogKd'];
		$methods[]="DAPF";
		echo "Converted p<i>K</i><sub>d</sub> is ".round($row['DAPF_neglogKd'], 2)."<br>";
		$kddapf =round( 1000000*pow(10, -1*$row['DAPF_neglogKd']), 2);
		echo "Converted dissociation constant is ".$kddapf." &micro;M<br>";


		if ($row['DAPF_n'] > 1){
			$kddapfmin =round((($row['DAPF_PEPconv_uM']/($row['DAPF_BI_norm_aver']-$row['DAPF_BI_norm_stdev']))-4-$row['DAPF_PEPconv_uM']+(($row['DAPF_BI_norm_aver']-$row['DAPF_BI_norm_stdev'])*4)),2);
			if (($row['DAPF_BI_aver']+$row['DAPF_BI_norm_stdev']) < 1){
				$kddapfmax =round((($row['DAPF_PEPconv_uM']/($row['DAPF_BI_norm_aver']+$row['DAPF_BI_norm_stdev']))-4-$row['DAPF_PEPconv_uM']+(($row['DAPF_BI_norm_aver']+$row['DAPF_BI_norm_stdev'])*4)),2);
			} else {
				$kddapfmax =round((($row['DAPF_PEPconv_uM']/0.999)-4-$row['DAPF_PEPconv_uM']+(0.999*4)),2);
			}
			echo "The real dissociation constant is somewhere between ".$kddapfmin."&micro;M and ".$kddapfmax."&micro;M (+/- 1 sigma)<br>";
		} else {
			$kddapfmin =round((($row['DAPF_PEPconv_uM']/($row['DAPF_BI_norm_aver']-0.025))-4-$row['DAPF_PEPconv_uM']+(($row['DAPF_BI_norm_aver']-0.025)*4)),2);
			if (($row['DAPF_BI_norm_aver']+0.025) < 1){
				$kddapfmax =round((($row['DAPF_PEPconv_uM']/($row['DAPF_BI_norm_aver']+0.025))-4-$row['DAPF_PEPconv_uM']+(($row['DAPF_BI_norm_aver']+0.025)*4)),2);
			} else {
				$kddapfmax =round((($row['DAPF_PEPconv_uM']/0.999)-4-$row['DAPF_PEPconv_uM']+(0.999*4)),2);
			}
			echo "Assuming uniform standard deviation in DAPF type experiments (sigma= 0.025 BI), the real dissociation constant is somewhere between ".$kddapfmin."&micro;M and ".$kddapfmax."&micro;M (-/+ 1 sigma)<br>";
		}
		
	} else {
		$pkds[]=3.5;
		$methods[]="DAPF";
		echo "Binding intensity is below detection threshold (2 sigma; 0.05 BI)<br>";
	}
	} else {
	echo "<br><img src='./lights/NM.png' width='20' height='20'>";
	echo "<br><b>No DAPF measurement is available. </b><br>";
	}















	if (!empty($row['CALIP_BI_aver'])) {
	echo "<br><img src='./lights/CALIP.png' width='20' height='20'>";
	echo "<br><b>Summary of holdup measurement with caliper readout</b><br>";
	if ($row['CALIP_METHOD'] == "LYSC"){
		echo "The holdup experiment was performed on bacterial lysate with caliper readout. (<b>LYSC</b>)<br>";
	} elseif ($row['CALIP_METHOD'] == "SAPC") {
		echo "The holdup experiment was performed on single affinity purified PDZ protein with caliper readout. (<b>SAPC</b>)<br>";
	}

	echo round($row['CALIP_n'])." experiments were performed<br>";
	if ($row['CALIP_n'] > 1){
		echo "The raw binding intensity is ". round($row['CALIP_BI_aver'], 2)." BI with a standard deviation of ".round($row['CALIP_BI_stdev'], 2)." BI<br>";
	} else {
		echo "The raw binding intensity is ". round($row['CALIP_BI_aver'], 2)." BI<br>";
	}
	echo "Peptide concentration for conversion is ".round($row['CALIP_PEPconv_uM'], 1)." &micro;M<br>";
	$thresholdLYSC= round(-log10((($row['CALIP_PEPconv_uM']/0.1)-4-$row['CALIP_PEPconv_uM']+(0.1*4))/1000000),2);
	echo "At this peptide concentration, the detection threshold at 0.10 BI is: ".$thresholdLYSC." p<i>K</i><sub>d</sub><br>";

	if ($row['CALIP_neglogKd'] > 0){
		$pkds[]=$row['CALIP_neglogKd'];
		$pkdsnoempty[]=$row['CALIP_neglogKd'];
		$methods[]=$row['CALIP_METHOD'];
		echo "Converted p<i>K</i><sub>d</sub> is ".round($row['CALIP_neglogKd'], 2)."<br>";
		$kdlysc = round(1000000*pow(10, -1*$row['CALIP_neglogKd']), 2);
		echo "Converted dissociation constant is ".$kdlysc." &micro;M<br>";



		if ($row['CALIP_n'] > 1){
			$kddapfmin =round((($row['CALIP_PEPconv_uM']/($row['CALIP_BI_aver']-$row['CALIP_BI_stdev']))-4-$row['CALIP_PEPconv_uM']+(($row['CALIP_BI_aver']-$row['CALIP_BI_stdev'])*4)),2);
			if (($row['CALIP_BI_aver']+$row['DAPF_BI_norm_stdev']) < 1){
				$kddapfmax =round((($row['CALIP_PEPconv_uM']/($row['CALIP_BI_aver']+$row['CALIP_BI_stdev']))-4-$row['CALIP_PEPconv_uM']+(($row['CALIP_BI_aver']+$row['CALIP_BI_stdev'])*4)),2);
			} else {
				$kddapfmax =round((($row['CALIP_PEPconv_uM']/0.999)-4-$row['CALIP_PEPconv_uM']+(0.999*4)),2);
			}
			echo "The real dissociation constant is somewhere between ".$kddapfmin."&micro;M and ".$kddapfmax."&micro;M (+/- 1 sigma)<br>";
		} else {
			$kddapfmin =round((($row['CALIP_PEPconv_uM']/($row['CALIP_BI_aver']-0.05))-4-$row['CALIP_PEPconv_uM']+(($row['CALIP_BI_aver']-0.05)*4)),2);
			if (($row['CALIP_BI_aver']+0.025) < 1){
				$kddapfmax =round((($row['CALIP_PEPconv_uM']/($row['CALIP_BI_aver']+0.025))-4-$row['CALIP_PEPconv_uM']+(($row['CALIP_BI_aver']+0.025)*4)),2);
			} else {
				$kddapfmax =round((($row['CALIP_PEPconv_uM']/0.999)-4-$row['CALIP_PEPconv_uM']+(0.999*4)),2);
			}
			echo "Assuming uniform standard deviation in ".$row['CALIP_METHOD']." type experiments (sigma= 0.05 BI), the real dissociation constant is somewhere between ".$kddapfmin."&micro;M and ".$kddapfmax."&micro;M (-/+ 1 sigma)<br>";
		}



	} else {
		$pkds[]=3.5;
		$methods[]=$row['CALIP_METHOD'];
		echo "Binding intensity is below detection threshold (2 sigma; 0.1 BI)<br>";
	}
	} else {
	echo "<br><img src='./lights/NM.png' width='20' height='20'>";
	echo "<br><b>No caliper measurement is available. </b><br>";
	}
	
	
	if (!empty($row['SAPF_BI_aver'])) {
	echo "<br><img src='./lights/SAPF.png' width='20' height='20'>";
	echo "<br><b>Summary of holdup measurement with single affinity purified PDZ protein coupled with fluorescent readout (SAPF)</b><br>";
	if ($row['SAPF_n'] == 0) {
		$row['SAPF_n'] = 1;
	} //correcting database error! Correct database and remove this!
	echo round($row['SAPF_n'])." SAPF experiments were performed<br>";
	if ($row['SAPF_n'] > 1){
		echo "The raw binding intensity is ". round($row['SAPF_BI_aver'], 2)." BI with a standard deviation of ".round($row['SAPF_BI_std'], 2)." BI<br>";
		echo "After correction to PDZ inactivity, the binding intensity is ". round($row['SAPF_BI_norm_aver'], 2)." BI with a standard deviation of ".round($row['SAPF_BI_norm_stdev'], 2)." BI<br>";
	} else {
		echo "The raw binding intensity is ". round($row['SAPF_BI_aver'], 2)." BI<br>";
		echo "After correction to PDZ inactivity, the binding intensity is ". round($row['SAPF_BI_norm_aver'], 2)." BI<br>";
	}
	echo "Peptide concentration for conversion is ".round($row['SAPF_PEPconv_uM'], 1)." &micro;M<br>";
	$thresholdSAPF= round(-log10((($row['SAPF_PEPconv_uM']/0.1)-4-$row['SAPF_PEPconv_uM']+(0.1*4))/1000000),2);
	echo "At this peptide concentration, the detection threshold at 0.10 BI is: ".$thresholdSAPF." p<i>K</i><sub>d</sub><br>";
	

	if ($row['SAPF_neglogKd'] > 0){
		$pkds[]=$row['SAPF_neglogKd'];
		$pkdsnoempty[]=$row['SAPF_neglogKd'];
		$methods[]="SAPF";
		echo "Converted p<i>K</i><sub>d</sub> is ".round($row['SAPF_neglogKd'], 2)."<br>";
		$kdsapf =round( 1000000*pow(10, -1*$row['SAPF_neglogKd']), 2);
		echo "Converted dissociation constant is ".$kdsapf." &micro;M<br>";








		if ($row['SAPF_n'] > 1){
			$kddapfmin =round((($row['SAPF_PEPconv_uM']/($row['SAPF_BI_norm_aver']-$row['SAPF_BI_norm_std']))-4-$row['SAPF_PEPconv_uM']+(($row['SAPF_BI_norm_aver']-$row['SAPF_BI_norm_std'])*4)),2);
			if (($row['SAPF_BI_norm_aver']+$row['SAPF_BI_norm_std']) < 1){
				$kddapfmax =round((($row['SAPF_PEPconv_uM']/($row['SAPF_BI_norm_aver']+$row['SAPF_BI_norm_std']))-4-$row['SAPF_PEPconv_uM']+(($row['SAPF_BI_norm_aver']+$row['SAPF_BI_norm_std'])*4)),2);
			} else {
				$kddapfmax =round((($row['SAPF_PEPconv_uM']/0.999)-4-$row['SAPF_PEPconv_uM']+(0.999*4)),2);
			}
			echo "The real dissociation constant is somewhere between ".$kddapfmin."&micro;M and ".$kddapfmax."&micro;M (+/- 1 sigma)<br>";
		} else {
			$kddapfmin =round((($row['SAPF_PEPconv_uM']/($row['SAPF_BI_norm_aver']-0.05))-4-$row['SAPF_PEPconv_uM']+(($row['SAPF_BI_norm_aver']-0.05)*4)),2);
			if (($row['SAPF_BI_aver']+0.05) < 1){
				$kddapfmax =round((($row['SAPF_PEPconv_uM']/($row['SAPF_BI_norm_aver']+0.05))-4-$row['SAPF_PEPconv_uM']+(($row['SAPF_BI_norm_aver']+0.05)*4)),2);
			} else {
				$kddapfmax =round((($row['SAPF_PEPconv_uM']/0.999)-4-$row['SAPF_PEPconv_uM']+(0.999*4)),2);
			}
			echo "Assuming uniform standard deviation in SAPF type experiments (sigma= 0.05 BI), the real dissociation constant is somewhere between ".$kddapfmin."&micro;M and ".$kddapfmax."&micro;M (-/+ 1 sigma)<br>";
		}







	} else {
		$pkds[]=3.5;
		$methods[]="SAPF";
		echo "Binding intensity is below detection threshold (0.1 BI)<br>";
	}
	} else {
	echo "<br><img src='./lights/NM.png' width='20' height='20'>";
	echo "<br><b>No SAPF measurement is available. </b><br>";
	}
	
	
	
}


if (count($methods)>1){
	// Function to calculate square of value - mean
	function sd_square($x, $mean) { return pow($x - $mean,2); }

	// Function to calculate standard deviation (uses sd_square)    
	function sd($array) {
	// square root of sum of squares devided by N-1
		return sqrt(array_sum(array_map("sd_square", $array, array_fill(0,count($array), (array_sum($array) / count($array)) ) ) ) / (count($array)-1) );
	}
	$average = array_sum($pkdsnoempty)/count($pkdsnoempty);
	if (count($pkdsnoempty)>0){
		echo '<br><hr><br>Based on '.count($pkdsnoempty).' methods, the average p<i>K</i><sub>d</sub> is '.round($average,2).' with a standard deviation of '.round(sd($pkds),2);

		$_SESSION['pkds'] = $pkds;
		$_SESSION['methods'] = $methods;
		$_SESSION['average'] = $average;
		echo '<br><br><img src="./pkddisp.php" class="centeredhalf" >';
		echo '<br><hr><br>';
	} else {
		echo '<br><hr><br>The interaction was unquantifiable in the experiments performed with  '.count($methods).' methods.<br><hr><br>';
	}

}
echo '<br><a href="search_b.php?searchpdz='.$PDZ.'">Back to PBM profile</a><br>';

echo '<a href="search.php?searchpbm='.$PBM.'">Back to PDZ profile</a><br>';
?>

<br>
<br>
<hr>
<footer style="text-align:center"><i>Please cite our work as Gogl et al., bioRxiv, 2021</i><br>
&copy; The profaff is a project of the Trave team colleciting data from the team and from a network of collaborators.</footer>
	</body>
</html>
