<!DOCTYPE html>
<?php

require_once('../PDZconnect.php');
?>
<html>
	<?php
	session_start();
	?>
	
	
<style>
.centeredhalfb{width:90%}
@media (min-width:1100px){.centeredhalf{width:80%}}

.slidecontainer {
  width: 100%;
}

.slider {
  -webkit-appearance: none;
  width: 75%;
  height: 10px;
  border-radius: 5px;
  background: #d3d3d3;
  outline: none;
  opacity: 1;
  -webkit-transition: .2s;
  transition: opacity .2s;
}

.slider:hover {
  opacity: 1;
}

.slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: #608bd2;
  cursor: pointer;
}

.slider::-moz-range-thumb {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: #608bd2;
  cursor: pointer;
}



.tooltip {
  position: relative;
  display: inline-block;
  color: #d3d3d3;
}

.tooltip .tooltiptext {
  visibility: hidden;
  width: 100px;
  background-color: black;
  color: #fff;
  text-align: left;
  border-radius: 6px;
  padding: 5px 5px;
  position: absolute;
  z-index: 1;
  top: 5px;
  right: 110%;
  opacity: 0;
  transition: all 1s;
}
.tooltip:hover .tooltiptext {
  visibility: visible;
  opacity: 1;
}

.tooltip .tooltiptextb {
  visibility: hidden;
  width: 200px;
  background-color: black;
  color: #fff;
  text-align: left;
  border-radius: 6px;
  padding: 5px 5px;
  position: absolute;
  z-index: 1;
  top: 5px;
  left: 110%;
  opacity: 0;
  transition: all 1s;
}
.tooltip:hover .tooltiptextb {
  visibility: visible;
  opacity: 1;
}

.w3-row-padding:after,.w3-row-padding:before{content:"";display:table;clear:both}
.w3-half{float:left;width:100%}
@media (min-width:1100px){.w3-half{width:49.9%}}

.w3-row-padding,.w3-row-padding>.w3-half{padding:0% 2.5%}



</style>
<meta name="viewport" content="width=device-width, initial-scale=1">

	
	<head>
		<title>PDZ-PBM interactome</title>
		<link rel="stylesheet" href="../assets/header-search.css">
		<script>
			var coll = document.getElementsByClassName("collapsible");
			var i;

			for (i = 0; i < coll.length; i++) {
			  coll[i].addEventListener("click", function() {
			    this.classList.toggle("active");
			    var content = this.nextElementSibling;
			    if (content.style.display === "block") {
			      content.style.display = "none";
			    } else {
			      content.style.display = "block";
			    }
			  });
			}
		</script>
	</head>

	<body style="min-width:600px;">

		<!-- THIS PART GENERATES THE MENU BAR WITH THE SEARCH FIELD -->
		<header class="header-search">
			<div class="header-limiter">
				<h1><a href="../index.php"><img src="../assets/profaff.png"  width='210' height='30' /></a></h1>
				<nav>
					<a href="PDZPBM.php">PDZ/PBM Interactome</a>
					<a href="method.php">Method</a>
					<a href="searchPBM.php" class="selectedb">Explore</a>
				</nav>

			</div>
		</header>

		<!-- THIS PART is about general info about the selected entry -->

<p></p>




		<p>
			<?php



				
				
				
				
				$table = $_GET['searchpdz'];
				
				$threshold=$_GET['threshold'];
				if (empty($threshold)) {
				$threshold=4;
				}
				//Here we define a pkd threshold for logo calculation. If nothing is posted, it is defined at 4 pkd by default




                if (!empty($table)) { 

				echo "<name>Selected PDZ: ".$table."</name>";;
			?>


			    <?php	
				    #echo '"' .$table . '"'; 
				    $loadingSequence = "SELECT UNIPROT, DOMAINS from domains WHERE PDZ = '".$table."'";
				    $Sequenceb = $conn->query($loadingSequence);
				    //$resultSeq = mysql_fetch_array($Sequence);
				    while ($row = $Sequenceb->fetch_assoc()) {
			     		echo '<br>Uniprot: <a href=https://www.uniprot.org/uniprot/'.$row['UNIPROT'].'>'.$row['UNIPROT'].'</a><br><br>';
					$tableuniprot = $row['UNIPROT'];
					echo "<img src='../gdraw.php?domains=".$row['DOMAINS']."' width='400' height='125' usemap='#workmap'>";
					$string=$row['DOMAINS'];

				    }
			    ?>

		<!-- Map for links -->
		<map name="workmap">
		<?php
		$pieces = explode(";", $string);
		$scale=350/$pieces[0];
		$protein = explode("_", $table);
		$counter = 0;
		//$alter=0;
		for ($i = 1; $i <= count($pieces)-1; $i++) {
		$bits = explode("-", $pieces[$i]);
		if ($bits[2] == 0) {
			$counter++;
		}
		if ($bits[2] == 1) {
			$counter++;
			$start = 25+($scale*$bits[0]);
			$end = 25+($scale*$bits[1]);
			echo "<area shape='rect' coords='".$start.",10,".$end.",40' href='search_b.php?searchpdz=".$protein[0]."_".$counter."'>";

		}
		if ($bits[2] == 1.5) {
			$counter++;
			$start = 25+($scale*$bits[0]);
			$end = 25+($scale*$bits[1]);
			echo "<area shape='rect' coords='".$start.",10,".$end.",40' href='search.php?searchpbm=".$protein[0]."'>";

		}

		if ($bits[2] == 0.38) {
			$counter++;
			$start = 25+($scale*$bits[0]);
			$end = 25+($scale*$bits[1]);
			echo "<area shape='rect' coords='".$start.",10,".$end.",40' href='../interactome-e6/searchmotif.php?searchmotif=".$protein[0]."'>";

		}

		if ($bits[3] == 'a') {
			$alter++;
		}
		}
		?>
		</map>
		<?php
		if ($alter >0) {
			echo '<br><br>Alternative motifs:<br>';
			$checklistpbm = $conn->query("SELECT PBM, UNIPROT from peptides WHERE UNIPROT = '".$tableuniprot."' ORDER BY PBM");
			while($rowd = $checklistpbm->fetch_assoc()) {
				if ($rowd["PBM"] != $table){
					echo '<a href="search.php?searchpbm='.$rowd["PBM"].'">PDZome binding profile of '. $rowd["PBM"] .'</a><br>';
				}
		}
		}
		?>
		<center>
		<form action="comparePDZ.php" method="get">
		<label>Compare with:</label>
		<select id="PDZ2" name="PDZ2" required>  
			<option value="" disabled selected>Select a PDZ</option> 
			<?php
			$PBMlist = $conn->query("SELECT PDZ from domains ORDER BY PDZ");
			while($rowb = $PBMlist->fetch_assoc()) {
							echo "<option value=".$rowb["PDZ"].">".$rowb["PDZ"]."</option> ";
						  }

			?>
		</select> 
		<?php
		echo '<input type="hidden" name="PDZ" value="'.$table.'" />';
		?>
		<input type="submit" value="Compare!"/>
		


			
		</form>
		</center>
		
		
		
			
		</p>

		<!-- separator line -->


<?php
$sql = "SELECT PDZ, PBM, peptide_10mer, COMP_neglogKd, source, LOGO from PDZPBM WHERE PDZ = '".$table."' AND COMP_neglogKd IS NOT NULL AND STATUS = 'PUBL' ORDER BY COMP_neglogKd DESC ";
$result = $conn->query($sql);
$datatoplot = array();
$peppos = array();
$pepweight = array();
$profilePDZ = array();
$profilePBM = array();
$profilepeptide_10mer = array();
$profileCOMP_neglogKd = array();
$profilesource = array();
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		$profilePDZ[] = $row["PDZ"];
		$profilePBM[] = $row["PBM"];
		$profilepeptide_10mer[] = $row["peptide_10mer"];
		$profileCOMP_neglogKd[] = $row["COMP_neglogKd"];
		$profilesource[] = $row["source"];
		if ($row["LOGO"] == 'YES'){
			if ($row["COMP_neglogKd"] > $threshold){
				for ($pos = 0; $pos <= 9; $pos++) {
					$peppos[$pos] .= substr($row["peptide_10mer"], $pos, 1);
					$pepweight[$pos][] = pow(10,($row["COMP_neglogKd"]-$threshold));
				}
			}
		}
		$datatoplot[] = $row["COMP_neglogKd"];
		}
		$_SESSION['plotdata'] = $datatoplot;
		$_SESSION['peppos'] = $peppos;
		$_SESSION['pepweight'] = $pepweight;
}
?>

		<hr>
			<!-- THIS PART is the 2 column stuff-->
			<div class="w3-row-padding">
				<!-- left column -->
					<div class="w3-half">
						<?php
							echo '<img src="../plot.php?title=PBMome binding profile&xaxis=PBM rank&threshold='.$threshold.'" class="center"><br/>';
						
						
						if (strlen($peppos[0]) > 0) {
						echo "<br/><center><b>Affinity weighted frequency plot of strong binders</b></center>";
						echo '<center><img src="../glogo.php" class="centeredhalfb" ><br>';
						echo "The plot was generated using ".strlen($peppos[0])." partners with p<i>K</i><sub>d</sub> > ".$threshold." found in the database for this PDZ domain.</center>";
						} else {
						echo "<center>There are no partners with p<i>K</i><sub>d</sub> > ".$threshold." for this PDZ domain in the database for affinity-weighted frequency plot calculation.</center>";
						}
						?>
						
<br><br>					
<center><b>Modify the threshold for plotting:</b></center>				

						
						
<!-- Set binding threshold -->	
<div class="slidecontainer">				
<center><form action="search_b.php" method="get">
<?php
$aposztrof="'";
    echo '<input type="range" min="3.5" max="6.5" step="0.1" value="'.$threshold.'" name="threshold" class="slider" id="myRange"/>';
    echo '<br>Threshold: <span id="demo"></span> p<i>K</i><sub>d</sub>&nbsp;&nbsp;&nbsp;&nbsp;<input type="hidden" name="searchpdz" value="'.$table.'" />';
?>

<script>
var slider = document.getElementById("myRange");
var output = document.getElementById("demo");
output.innerHTML = slider.value;

slider.oninput = function() {
  output.innerHTML = this.value;
}
</script>
<input type=submit value="Reset threshold" />
</form></center>
</div>
						<br>
						
						
						
						
						<?php
					    echo '<br><center><a href="../dump.php?type=PDZ&carryon='.$table.'" target="_blank">Download detailed data in csv format</a></center><br>';
                        ?>
					</div>
				<div class="w3-half">
					<!-- left column -->
					<!-- <button type="button" class="collapsible">Show/hide data</button> -->
					<!-- <div class="content"> -->
						<div style="height:600px; overflow-y:scroll; overflow-x:hidden;min-width:490px;">
						<table>
							<tr>
							<th>PBM </th>
						    <th style="text-align:left">10mer sequence </th>
						    <th style="text-align:left">p<i>K</i><sub>d</sub> <div class="tooltip"><img src="../assets/infow.png" width=15 length=15/>
								<span class="tooltiptextb">
								p<i>K</i><sub>d</sub> = -log<sub>10</sub>(K</i><sub>d</sub>))<br><br>
								taken from most reliable holdup method<br>
<img src=./lights/DAPF.png width=10 height=10 > > <img src=./lights/CALIP.png width=10 height=10 > > <img src=./lights/SAPF.png width=10 height=10 >
								</span>
								</div></th>
						    <th style="text-align:left">source <div class="tooltip"><img src="../assets/infow.png" width=15 length=15/>
								<span class="tooltiptext">
								<img src=./lights/FP.png width=20 height=20 > FP<br>
								<img src=./lights/DAPF.png width=20 height=20 > DAPF<br>
								<img src=./lights/CALIP.png width=20 height=20 > CALIP<br>
								<img src=./lights/SAPF.png width=20 height=20 > SAPF<br>

								</span>
								</div></th>
							</tr>

							<?php
							$length = count($profileCOMP_neglogKd);
							for ($element = 0; $element < $length; $element++) {
								if($profileCOMP_neglogKd[$element] > 3.5) {
									echo '<tr><td><a href="search.php?searchpbm='.$profilePBM[$element].'">'. $profilePBM[$element] .'</a></td><td>'. $profilepeptide_10mer[$element] .'</td><td>'. round($profileCOMP_neglogKd[$element], 2) .'</td><td><a href="details.php?pdz='.$profilePDZ[$element].'&pbm='.$profilePBM[$element].'"><img src=./lights/'.$profilesource[$element].'.png width=92 height=20 /></a></td></tr>';
								} else {
									echo '<tr><td><a href="search.php?searchpbm='.$profilePBM[$element].'">'. $profilePBM[$element] .'</a></td><td>'. $profilepeptide_10mer[$element] .'</td><td>below threshold</td><td><a href="details.php?pdz='.$profilePDZ[$element].'&pbm='.$profilePBM[$element].'"><img src=./lights/'.$profilesource[$element].'.png width=92 height=20 /></a></td></tr>';
								}
							}
							?>
						</table></div>
					<!-- </div> -->
				</div>
					<!-- right column -->

			</div>



        <?php
        }
        ?>
<br>
<br>
<hr>
<footer style="text-align:center"><i>Please cite our work as Gogl et al., bioRxiv, 2021</i><br>
&copy; The profaff is a project of the Trave team colleciting data from the team and from a network of collaborators.</footer>

        <?php
        $conn->close();
	session_close();
        ?>


	</body>
</html>

