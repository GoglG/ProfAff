<!DOCTYPE html>
<?php

?>
<?php
session_destroy();
?>
<html>

<head>




	<title>14-3-3/phosphopeptide Interactome</title>

	<link rel="stylesheet" href="../assets/header-search.css">


</head>

<body>


<header class="header-search">

	<div class="header-limiter">

		<h1><a href="../index.php"><img src="../assets/profaff.png"  width='210' height='30' /></a></h1>

		<nav>
			<a href="YWHAx.php">14-3-3/phosphopeptide Interactome</a>
			<a href="#"class="selected">Method</a>
			<a href="search.php">Explore</a>
		</nav>



	</div>



</header>
<br>
<p><name>Competitive fluorescence polarization</name><br>
Fluorescence polarization assay is a robust affinity measurement method than can be easily parralelized.
In direct fluorescence polarization (FP) experiments, a fluorescent probe (usually a labeled peptide) is titrated with a globular partner. Their association is monitored by the polarization of the emitted light of the fluorophore. In a modified FP experiment called competitive assay, both the probe and partner concentration are fixed, and the reaction mixture is titrated with an unlabeled competitor molecule (peptide or protein). Depolarization of the emitted light is indicative of the competition between the probe and the competitor in binding to the partner. While direct FP can be perturbed by the presence of the fluorescent dye, the competitive assay is unbiased and therefore more suitable for accurate HTP measurements of dissociation constants. FP data is analyzed with our python-based program called <a href="https://github.com/GoglG/ProFit">ProFit</a>.
</p><br><br>

<hr>

<br>
<center><name>Key references</name></center>
<p style="margin: 00px 100px 00px 100px;">
- High‐throughput competitive fluorescence polarization assay reveals functional redundancy in the S100 protein family. <i>M. A. Simon et al. FEBS Journal, 2019</i><br>
</p>


<br>
<br>
<hr>
<footer style="text-align:center"><i>Please cite our work as Gogl et al., bioRxiv, 2021</i><br>
&copy; The profaff is a project of the Trave team colleciting data from the team and from a network of collaborators.</footer>

</body>

</html>
