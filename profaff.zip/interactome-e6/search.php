<!DOCTYPE html>
<?php
require_once('../PDZconnect.php');
?>
<html>
<style>
.w3-row-padding:after,.w3-row-padding:before{content:"";display:table;clear:both}
.w3-half{float:left;width:100%}
@media (min-width:1100px){.w3-half{width:49.9%}}

.w3-row-padding,.w3-row-padding>.w3-half{padding:0% 2.5%}


</style>
<head>




	<title>E6/LxxLL interactome</title>

	<link rel="stylesheet" href="../assets/header-search.css">


</head>

<body>


<header class="header-search">

	<div class="header-limiter">

		<h1><a href="../index.php"><img src="../assets/profaff.png"  width='210' height='30' /></a></h1>

		<nav>
			<a href="YWHAx.php">E6/LxxLL interactome</a>
			<a href="method.php">Method</a>
			<a href="#" class="selected">Explore</a>
		</nav>



	</div>



</header>
<br>

<div class="w3-row-padding">
	<div class="w3-half">
		
		

		<p><b  style="font-size:20px">Search by E6 protein</b>
		<center>
		<form action="searchiso.php" method="get">
		<label>Select an E6 protein!</label>
		<select id="searchiso" name="searchiso" required>  
			<option value="" disabled selected>Choose a protein</option> 
			<?php
			$PBMlist = $conn->query("SELECT E6 from E6ome WHERE STATUS = 'PUBL'  ORDER BY E6");
			while($rowb = $PBMlist->fetch_assoc()) {
							echo "<option value=".$rowb["E6"].">".$rowb["E6"]."</option> ";
						  }
			?>
		</select> 
		<input type="submit" value="Go!"/>
		</form>
		</center></p>


	</div>
	<div class="w3-half">
		
		
		<p><b  style="font-size:20px">Search by LxxLL motifs</b>
		<center>
		<form action="searchmotif.php" method="get">
		<label>Select a motif!</label>
		<select id="searchmotif" name="searchmotif" required>  
			<option value="" disabled selected>Choose a motif</option> 
			<?php
			$PBMlist = $conn->query("SELECT MOTIF from LxxLLome WHERE STATUS = 'PUBL'  ORDER BY MOTIF");
			while($rowb = $PBMlist->fetch_assoc()) {
							echo "<option value=".$rowb["MOTIF"].">".$rowb["MOTIF"]."</option> ";
						  }
			?>
		</select> 
		<input type="submit" value="Go!"/>
		</form>
		</center></p>
	</div>
</div>
<br>
<hr>
<footer style="text-align:center"><i>Please cite our work as Gogl et al., bioRxiv, 2021</i><br>
&copy; The profaff is a project of the Trave team colleciting data from the team and from a network of collaborators.</footer>


</body>

</html>

