<!DOCTYPE html>
<?php

require_once('../PDZconnect.php');
session_start();
session_destroy();
?>
<html>
<style>
.tooltip {
  position: relative;
  display: inline-block;
  color: black;
}

.tooltip .tooltiptext {
  visibility: hidden;
  width: 400px;
  background-color: black;
  color: #fff;
  text-align: left;
  border-radius: 6px;
  padding: 5px 5px;
  position: absolute;
  z-index: 1;
  bottom: 100%;
  left: 50%;
  margin-left: -200px; /* Use half of the width (120/2 = 60), to center the tooltip */
  opacity: 0;
  transition: all 1s;
}
.tooltip:hover .tooltiptext {
  visibility: visible;
  opacity: 1;
}

.w3-row-padding:after,.w3-row-padding:before{content:"";display:table;clear:both}
.w3-third{float:left;width:100%}
@media (min-width:900px){.w3-third{width:33.33333%}}
.w3-row-padding,.w3-row-padding>.w3-half{padding:0% 2.5%}

.centeredhalf{width:50%}
@media (min-width:1000px){.centeredhalf{width:65%}}



</style>
<meta name="viewport" content="width=device-width, initial-scale=1">

<head>




	<title>PDZ-PBM interactome</title>

	<link rel="stylesheet" href="../assets/header-search.css">


</head>

<body>


<header class="header-search">
	<div class="header-limiter">
		<h1><a href="../index.php"><img src="../assets/profaff.png"  width='210' height='30' /></a></h1>
		<nav>
			<a href="PDZPBM.php">PDZ/PBM Interactome</a>
			<a href="method.php">Method</a>
			<a href="#" class="selected">Explore</a>
		</nav>



	</div>



</header>
<br>
<p>You can browse the database in 3 different ways. You can either directly select a specific domain or a motif, or you can also search among all motifs by their sequence.</p>
<p>Proteins are identified by their gene id apart from a few PDZ proteins where trivial names are used.</p>
<br>
<hr>


<div class="w3-third w3-container">
<center>
<img src="./img/domain.png" class="centeredhalf"/><p><b  style="font-size:20px"><br><div class="tooltip">Search by domains</b> <img src="../assets/info.png" width=20 length=20/>
								<span class="tooltiptext">
								Search by typing or browsing PDZ-domains by their gene ID.
								</span>
								</div>

	<form action="search_b.php" method="get">
		<label>Select a PDZ!</label>
		<select id="searchpdz" name="searchpdz" required>  
			<option value="" disabled selected>Choose a PDZ</option> 
			<?php
			$PBMlist = $conn->query("SELECT PDZ from domains ORDER BY PDZ");
			while($rowb = $PBMlist->fetch_assoc()) {
							echo "<option value=".$rowb["PDZ"].">".$rowb["PDZ"]."</option> ";
						  }
			?>
		</select> 
		<input type="submit" value="Go!"/>
	</form>
</center>
</p>
</div>

<div class="w3-third w3-container">
<center>

<img src="./img/peptide.png" class="centeredhalf" /><p><b  style="font-size:20px"><br><div class="tooltip">Search by motifs</b> <img src="../assets/info.png" width=20 length=20/>
								<span class="tooltiptext">
								Search by typing or browsing PBMs by their gene ID.
								</span>
								</div>

<form action="search.php" method="get">
<label>Select a PBM!</label>
<select id="searchpbm" name="searchpbm" required>  
	<option value="" disabled selected>Choose a PBM</option> 
	<?php
	$PBMlist = $conn->query("SELECT PBM from peptides WHERE STATUS = 'PUBL'  ORDER BY PBM");
	while($rowb = $PBMlist->fetch_assoc()) {
					echo "<option value=".$rowb["PBM"].">".$rowb["PBM"]."</option> ";
				  }
	?>
</select> 
<input type="submit" value="Go!"/>
</form>
</center></p>
</div>


<div class="w3-third w3-container">
	<center>
<img src="./img/glogo.png" class="centeredhalf" /><p><b  style="font-size:20px"><br><div class="tooltip"> Search by sequence</b> <img src="../assets/info.png" width=20 length=20/>
								<span class="tooltiptext">
								Search by typing exact an sequence or a consensus motif.<br>
								The length can be 1-10 residue long<br>
								"." indicate any residue<br>
								residues between [ ] indicate alternative residues<br>
								Example 1: ETAL<br>
								Example 2: ETA[LV]<br>
								Example 3: ET.L<br>
								Example 4: R.E[ST].[LV]<br>
								</span>
								</div>

	<form method="post">
	 <label>Search a sequence or a consensus motif (C-terminal 1-10mer sequence)</label>
	 <input type="text" name="search" placeholder="RRE[TS].L" required>
	 <input type="submit" name ="submit" value="Show!">
	 
	 </form>
	</center>

</p>


</div>



 <?php
 
 #require_once('functions.php');
 
 #$db = new DB();
 #$data = $db->PBMsearch();
 ?>

<?php #echo $data ?>





		<?php
		if (isset($_POST["submit"])) {
        		$str = strtoupper($_POST["search"]);
		}
		if (!empty($str)) {
			$strInput = $str;
			$bracket = substr_count($str, '['); #Search how many brackets are in the input string
			for ($j = 1; $j <= $bracket ; $j++)  # looping according to the bracket instances
				{	
  				${"val".$j} = substr($str, strpos($str, "["), strpos($str, "]") - strpos($str, "[") + 1); # identifying the brackets and create a variable on the fly to store it
				if (!is_numeric(${"val".$j}) && ${"val".$j} != "."){ # Avoids string substitution if repeated bracket or dot
					$str = str_replace(${"val".$j}, $j, $str); # Replacing bracket by variable number, to be used later as a dictionary (number bracket = number variable)
					}
				}    

		if (strlen($str) <= 10) {
			echo '<p><name>Input sequence: '.$strInput.'</name></p>';
			
			$table = array();
			$PBMlist = $conn->query("SELECT PBM, sequence from peptides WHERE STATUS = 'PUBL' ORDER BY PBM");
			while($i = $PBMlist->fetch_assoc()) {
				#$str = strtoupper($str); #input string convert to UPPERCASE
				$i["sequence"] = preg_replace("/(?![A-Z])./", "", $i["sequence"]); #Removing lowercase from the database

				$x = 1; #Character start
				$countSubst = strlen($str); #Starting statement: both sequences are completely different, to substract according the similarity

				while($x <= strlen($str)) { #loop input string by length
					$c = substr($str, -$x, 1); #extracting letter by round from input string
  					$d = substr($i["sequence"], -$x, 1); #extracting letter by round from sequence database
  
    					if (is_numeric($c)){  #check if letter input string is numeric (therefore, if it corresponds to a bracket)
    						if (substr_count(${"val".$c}, $d) > 0 ) {  #if yes, search if variable number bracket contains letter in the position in sequence database
        
  						$countSubst--; #Substracting countSubst means there is a match
        					}
						}
    					elseif ($c == ".") { #if input string contains ".", means a match
    						$countSubst--; #Substracting countSubst means there is a match
						}
						elseif ($c == $d) { #direct compatison between input string and sequence database by position
  						$countSubst--; #Substracting countSubst means there is a match
						}
  					$x++; #end of round
				}
					$line = array($i["PBM"], substr(preg_replace("/(?![A-Z])./", "", $i["sequence"]),-strlen($str)),$countSubst );
				$table[] = $line;
			}
			echo '<br>';
			echo '<br>';




			echo "<div style='height:500px; ; overflow-y:scroll; overflow-x:hidden;min-width:400px;margin:5%'><table>";
				echo "<tr>";
				echo "<th>PBM </th>";
				echo "<th>sequence </th>";
				echo "<th>N substitutions </th></tr>";


			$x = 0;
			while($x <= strlen($str)) {
				#echo "<br>The number of mutation is: $x <br>";
				$j=0;
				#$jmax=count($table);
				#echo $jmax;
				while($j <= count($table)-1) {
					if ($x == $table[$j][2]) {
						#echo '<br>'.$table[$j][0];
						echo '<tr><td><a href="search.php?searchpbm='.$table[$j][0].'">'. $table[$j][0] .'</a></td><td>'. $table[$j][1] ."</td><td>". $table[$j][2] .'</td></tr>';
					}
					$j++;
				}
				$x++;
			} 

			echo "</table></div>";
		}
		}
        $conn->close();




?>







<br>
<hr>
<footer style="text-align:center"><i>Please cite our work as Gogl et al., bioRxiv, 2021</i><br>
&copy; The profaff is a project of the Trave team colleciting data from the team and from a network of collaborators.</footer>


</body>

</html>

