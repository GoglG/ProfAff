<!DOCTYPE html>
<?php

require_once('../PDZconnect.php');
?>
<html>
<?php
    session_destroy();
	session_start();
?>
<style>
.w3-row-padding:after,.w3-row-padding:before{content:"";display:table;clear:both}
.w3-half{float:left;width:100%}
@media (min-width:1100px){.w3-half{width:49.9%}}

.w3-row-padding,.w3-row-padding>.w3-half{padding:0% 2.5%}



</style>
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>




	<title>PDZ-PBM interactome</title>

	<link rel="stylesheet" href="../assets/header-search.css">


</head>

<body>


<header class="header-search">

	<div class="header-limiter">

		<h1><a href="../index.php"><img src="../assets/profaff.png"  width='210' height='30' /></a></h1>

		<nav>
					<a href="PDZPBM.php">PDZ/PBM Interactome</a>
					<a href="method.php">Method</a>
					<a href="searchPBM.php" class="selectedb">Explore</a>
		</nav>



	</div>



</header>




		
			<!-- left column -->
			

					<!-- compare start -->
					
                    

					<?php

						
						
					
						$compared = $_GET["PBM2"];
						
						$table = $_GET["PBM"];
						
						if (!empty($compared)) {
                       			 if (!empty($table)) {
							echo "<br><center><name>".$table." vs. ".$compared."</name><br><br>";

							$loadingSequence = "SELECT sequence, PBM from peptides WHERE (PBM = '".$table."' AND STATUS = 'PUBL') OR (PBM = '".$compared."' AND STATUS = 'PUBL')";
							$Sequenceb = $conn->query($loadingSequence);

							while ($row = $Sequenceb->fetch_assoc()) {
							echo '10-mer sequence of '.$row['PBM'].': '.$row['sequence'].'<br>';
							}


							echo '<a href="comparePBM.php?PBM2='.$table.'&PBM='.$compared.'">Reverse comparison</a><br>';
							echo '<a href="search.php?searchpbm='.$table.'">Jump to the profile of '.$table.'</a><br>';
							echo '<a href="search.php?searchpbm='.$compared.'">Jump to the profile of '.$compared.'</a><br></center><hr>';
							
							
							
							$master = $conn->query("SELECT PDZ, COMP_neglogKd FROM PDZPBM WHERE PBM = '".$table."' AND STATUS = 'PUBL' ORDER BY PDZ");
							$slave = $conn->query("SELECT PDZ, COMP_neglogKd FROM PDZPBM WHERE PBM = '".$compared."' AND STATUS = 'PUBL' ORDER BY PDZ");
							$masterarray = array();
							$slavearray = array();
							while($rowmaster = $master->fetch_assoc()) {
								$masterarray[] = array($rowmaster["PDZ"], $rowmaster["COMP_neglogKd"]);
							}
							#print_r($masterarray);
							while($rowslave = $slave->fetch_assoc()) {
								$slavearray[] = array($rowslave["PDZ"], $rowslave["COMP_neglogKd"]);
							}
							#print_r($slavearray);
							#echo count($masterarray);

							$profile1 = array();
							$profile2 = array();
                            $profilename = array();
							$x = -1;


							while($x <= count($masterarray)) {
								$x++;
								#echo "The number is: $x <br>";
								#echo $masterarray[$x][0];
								if (!empty($masterarray[$x][1])){
									#ahol van affinitas adat a master profilban
									$y = -1;
									while($y <= count($slavearray)) {
										$y++;
										if ($masterarray[$x][0] == $slavearray[$y][0]){
												if (!empty($slavearray[$y][1])){
                                                    $profilename[] = $masterarray[$x][0];
													$profile1[] = $masterarray[$x][1];
													$profile2[] = $slavearray[$y][1];
													#echo "ok";
												}
													#echo "nope";
												#$x = 100000000;
												$y = 100000000;

										}
									}
								}
								
							} 

                            array_multisort($profile1, SORT_DESC, $profile2, $profilename);

							$_SESSION['profile1'] = $profile1; #save this into session
							$_SESSION['profile2'] = $profile2; #save this into session
							
							echo "<div class='w3-row-padding'>"; ?>
							
							
							
							
							
							
							<div class="w3-half">
<?php
$ref = 0;
$comp = 0;
$both = 0;
$none = 0;
for ($x = 0; $x <= (count($profilename)-1); $x++) {		
	if ($profile1[$x] > 3.5 && $profile2[$x] > 3.5) {							
		$both++;
	}		
	if ($profile1[$x] < 3.5 && $profile2[$x] < 3.5) {
		$none++;
	}
	if ($profile1[$x] < 3.5 && $profile2[$x] > 3.5) {				
		$comp++;
	}

	if ($profile1[$x] > 3.5 && $profile2[$x] < 3.5) {				
		$ref++;
	}	
}
							echo "<img src='../plotcompare.php?xaxis=PDZ rank&title=PDZome binding profile&ref=".$table."&comp=".$compared."' class='center'><br>";
							echo "<center><img src='venn.php?ref=".$ref."&comp=".$comp."&both=".$both."&none=".$none."' width='300' height='232.5'></center>";
							
							

							
?>
</div>

							
							
							
							
							
							
							
							
							
							<?php
							echo "<div class='w3-half'><center>";
							

							echo "<br>";
							echo "<div style='height:500px; overflow-y:scroll; overflow-x:hidden;min-width:400px;'><table>";
						    echo "    <tr>";
						    echo "    <th>PDZ </th>";
						    echo "    <th>p<i>K</i><sub>d</sub><sub>1</sub> - ".$table." </th>";
                            echo "    <th>p<i>K</i><sub>d</sub><sub>2</sub> - ".$compared." </th><th>&Delta;p<i>K</i><sub>d</sub><sub>2-1</sub></th></tr>";








                            #print_r($profilename);

				$ref = 0;
				$comp = 0;
				$both = 0;
				$none = 0;
                            for ($x = 0; $x <= (count($profilename)-1); $x++) {
                            #echo $profilename[$x];

                              if ($profile1[$x] > 3.5 && $profile2[$x] > 3.5) {
					echo "<tr><td><a href='search_b.php?searchpdz=".$profilename[$x]."'>". $profilename[$x] ."</a></td><td>". round($profile1[$x], 2) ."</td><td>". round($profile2[$x], 2) ."</td><td>".round($profile2[$x]-$profile1[$x], 2)."</td></tr>";
					$both++;
					}
				if ($profile1[$x] < 3.5 && $profile2[$x] < 3.5) {
					echo "<tr><td><a href='search_b.php?searchpdz=".$profilename[$x]."'>". $profilename[$x] ."</a></td><td>below threshold</td><td>below threshold</td><td>unknown</td></tr>"; 
					$none++;
					}
				if ($profile1[$x] < 3.5 && $profile2[$x] > 3.5) {
					echo "<tr><td><a href='search_b.php?searchpdz=".$profilename[$x]."'>". $profilename[$x] ."</a></td><td>below threshold</td><td>". round($profile2[$x], 2) ."</td><td>unknown</td></tr>"; 
					$comp++;
					}
				if ($profile1[$x] > 3.5 && $profile2[$x] < 3.5) {	
					echo "<tr><td><a href='search_b.php?searchpdz=".$profilename[$x]."'>". $profilename[$x] ."</a></td><td>". round($profile1[$x], 2) ."</td><td>below threshold</td><td>unknown</td></tr>"; 
					$ref++;				
					}
#### Replace this for a different threshold					
#				if ($profile1[$x] > 4 && $profile2[$x] > 4) {
#					$INT++;
#					$UNIO++;
#					}
#				if ($profile1[$x] < 4 && $profile2[$x] < 4) {
#					$NEGUNIO++;
#					$NEGINT++;
#					}
#				if ($profile1[$x] < 4 && $profile2[$x] > 4) {
#					$NEGUNIO++;
#					$UNIO++;
#					}
#				if ($profile1[$x] > 4 && $profile2[$x] < 4) {	
#					$NEGUNIO++;
#					$UNIO++;				
#					}
                            
                            }
					        echo "</table></div>";
							#print_r( $profile1);
							
						}}
                        $conn->close();
					
					
					?>




					<!-- compare end -->








<br>
</div>

</div>







<br>
<br>
<hr>
<footer style="text-align:center"><i>Please cite our work as Gogl et al., bioRxiv, 2021</i><br>
&copy; The profaff is a project of the Trave team colleciting data from the team and from a network of collaborators.</footer>



</body>

</html>
