<!DOCTYPE html>
<?php

require_once('../PDZconnect.php');
?>
<html>
	<?php
	session_start();
	?>
<style>
.w3-row-padding:after,.w3-row-padding:before{content:"";display:table;clear:both}
.w3-half{float:left;width:100%}
@media (min-width:1100px){.w3-half{width:49.9%}}

.w3-row-padding,.w3-row-padding>.w3-half{padding:0% 2.5%}


</style>
	<head>
		<title>14-3-3/phosphopeptide Interactome</title>
		<link rel="stylesheet" href="../assets/header-search.css">
		<script>
			var coll = document.getElementsByClassName("collapsible");
			var i;

			for (i = 0; i < coll.length; i++) {
			  coll[i].addEventListener("click", function() {
			    this.classList.toggle("active");
			    var content = this.nextElementSibling;
			    if (content.style.display === "block") {
			      content.style.display = "none";
			    } else {
			      content.style.display = "block";
			    }
			  });
			}
		</script>
	</head>

	<body>

		<!-- THIS PART makes the connection to the mysql server -->


		<!-- THIS PART GENERATES THE MENU BAR WITH THE SEARCH FIELD -->
		<header class="header-search">
			<div class="header-limiter">
				<h1><a href="../index.php"><img src="../assets/profaff.png"  width='210' height='30' /></a></h1>
				<nav>
					<a href="YWHAx.php">14-3-3/phosphopeptide Interactome</a>
					<a href="method.php">Method</a>
					<a href="search.php" class="selectedb">Explore</a>

				</nav>







			</div>
		</header>

		<!-- THIS PART is about general info about the selected entry -->
<p></p>		



            <p>
			<?php
			
				
				$table = $_GET['searchiso'];
				

				 if (!empty($table)) { 
				    echo "<name>Selected 14-3-3 isoform: ".$table."</name><p>";


			if ($table == 'gamma'){
			echo 'Uniprot: <a href="https://www.uniprot.org/uniprot/P61981">P61981</a><br>';
			echo "<img src='../gdraw.php?domains=247;1-238-0.145' width='400' height='125'>";
			} elseif ($table == 'eta'){
			echo 'Uniprot: <a href="https://www.uniprot.org/uniprot/Q04917">Q04917</a><br>';
			echo "<img src='../gdraw.php?domains=246;2-246-0.145' width='400' height='125'>";
			} elseif ($table == 'zeta'){
			echo 'Uniprot: <a href="https://www.uniprot.org/uniprot/P63104">P63104</a><br>';
			echo "<img src='../gdraw.php?domains=245;1-229-0.145' width='400' height='125'>";
			} elseif ($table == 'beta'){
			echo 'Uniprot: <a href="https://www.uniprot.org/uniprot/P31946">P31946</a><br>';
			echo "<img src='../gdraw.php?domains=246;1-239-0.145' width='400' height='125'>";
			} elseif ($table == 'epsilon'){
			echo 'Uniprot: <a href="https://www.uniprot.org/uniprot/P62258">P62258</a><br>';
			echo "<img src='../gdraw.php?domains=255;3-232-0.145' width='400' height='125'>";
			} elseif ($table == 'tau'){
			echo 'Uniprot: <a href="https://www.uniprot.org/uniprot/P27348">P27348</a><br>';
			echo "<img src='../gdraw.php?domains=245;1-234-0.145' width='400' height='125'>";
			} elseif ($table == 'sigma'){
			echo 'Uniprot: <a href="https://www.uniprot.org/uniprot/P31947">P31947</a><br>';
			echo "<img src='../gdraw.php?domains=248;1-231-0.145' width='400' height='125'>";
			}



			echo '</p>';
			?>

		    <!-- separator line -->
		    <hr>

		    <!-- THIS PART is the 2 column stuff-->




		    <div class="w3-row-padding">
			    <!-- left column -->
			    <div class="w3-half">
				    <!-- left column -->
				    <!-- <button type="button" class="collapsible">Show/hide data</button> -->
				    <!-- <div class="content"> -->

					    <table>
						    <tr>
						    <th>Binding partner </th>
						    <th>binding motif </th>
						    <th style="text-align:left">p<i>K</i><sub>d</sub></th>
						    <th style="text-align:left">method </th>

					   
							    </tr>
							    <?php
								    $sql = "SELECT ISO, MOTIF, FP_aver_uM, FP_MODE, SEQUENCE from YWHAdata WHERE ISO = '".$table."' AND FP_aver_uM IS NOT NULL AND STATUS = 'PUBL' ORDER BY FP_aver_uM ASC ";
								    $result = $conn->query($sql);
								    $datatoplot = array();
									$peppos = array();
									$pepweight = array();
								    if ($result->num_rows > 0) {
									    while($row = $result->fetch_assoc()) {
										$pKd = -1*(log10($row["FP_aver_uM"]/1000000));


									    if($pKd > 3.6) {
									    
                                            						echo '<tr><td><a href="searchmotif.php?searchmotif='.$row["MOTIF"].'">'. $row["MOTIF"] .'</a></td><td>'.$row["SEQUENCE"].'</td><td>'. round($pKd, 2) .'</td> <td><a href="details.php?iso='.$row["ISO"].'&motif='.$row["MOTIF"].'">'. $row["FP_MODE"] .'</a></td>  </tr>';
											$datatoplot[] = $pKd;
											} else {
											echo '<tr><td><a href="searchmotif.php?searchmotif='.$row["MOTIF"].'">'. $row["MOTIF"] .'</a></td><td>'.$row["SEQUENCE"].'</td><td>< 3.6</td> <td><a href="details.php?iso='.$row["ISO"].'&motif='.$row["MOTIF"].'">'. $row["FP_MODE"] .'</a></td>  </tr>';
											$datatoplot[] = 0;

									     }


                                           					if ($pKd > 4){
                                           						for ($pos = 0; $pos <= 9; $pos++) {
												$peppos[$pos] .= substr($row["SEQUENCE"], $pos, 1);
												$pepweight[$pos][] = pow(10,($pKd-4));
											}
                                           					}


								    }
								    } else {
									    echo "0 results";
								    }
								$_SESSION['plotdata'] = $datatoplot;
								$_SESSION['peppos'] = $peppos;
								$_SESSION['pepweight'] = $pepweight;
							    ?>
						    </table>
					    
				    <!-- </div> -->
			    </div>
				    <!-- right column -->
				    <div class="w3-half">
					<img src="../plot.php?title=14-3-3 binding motif profile&xaxis=14-3-3 BM rank" class="center">
						<br/>
						
						<?php
						if (strlen($peppos[0]) > 0) {
						echo "<br/><center><b>Affinity weighted frequency plot of strong binders</b></center>";
						echo '<center><img src="../glogo.php" class="center" ></center>';
						echo "<center>The plot was generated using ".strlen($peppos[0])." partners with p<i>K</i><sub>d</sub> > 4 found in the database for this 14-3-3 isoform.</center>";
						} else {
						echo "<center>There are no partners with p<i>K</i><sub>d</sub> > 4 for this 14-3-3 isoform in the database for affinity-weighted frequency plot calculation.</center>";
						}
						
						
					    
                        ?>
				    </div>
		    </div>
        <?php
        }
        $conn->close();
        ?>
<br>
<br>
<hr>
<footer style="text-align:center"><i>Please cite our work as Gogl et al., bioRxiv, 2021</i><br>
&copy; The profaff is a project of the Trave team colleciting data from the team and from a network of collaborators.</footer>

	</body>
</html>
