<?php
#Examples, modify the following parameters according to the local mysql settings
    $servername = "servername";
    $username = "username";
    $password = "password";
    $database = "database";
    $conn = new mysqli($servername, $username, $password);
    if ($conn->connect_error) {
        die("Connection failed: ".$conn-connect_error);
    } 
    $conn->select_db($database);
?>
