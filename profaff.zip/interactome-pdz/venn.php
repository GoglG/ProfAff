<?php // content="text/plain; charset=utf-8"
// Change this defines to where Your fonts are stored
DEFINE("TTF_DIR","/usr/share/fonts/truetype/dejavu/");
 
// Change this define to a font file that You know that You have
DEFINE("TTF_FONTFILE","DejaVuSerif.ttf");



$ref = $_GET['ref'];
$comp = $_GET['comp'];
$none = $_GET['none'];
$both = $_GET['both'];
$Jneg = $none / ($none+$ref+$comp);
$Jint = $both / ($both+$ref+$comp);

$im = imagecreatetruecolor (400, 320);
$white = imagecolorallocate ($im, 234, 240, 242);
$black = imagecolorallocate ($im, 41, 44, 47);
$border_color = imagecolorallocate ($im, 41, 44, 47);

imagesetthickness($im, 3);

imagefilledrectangle($im,0,0,400,320,$white); //background
imagerectangle($im,10,10,390,290,$border_color); //outer rectangle
imageellipse($im, 140, 135, 200, 180, $border_color); // 1. ellipse
imageellipse($im, 140, 135, 199, 179, $border_color); // 1. ellipse
imageellipse($im, 140, 135, 198, 178, $border_color); // 1. ellipse
imageellipse($im, 140, 135, 197, 177, $border_color); // 1. ellipse
imageellipse($im, 260, 135, 200, 180, $border_color); //2. ellipse
imageellipse($im, 260, 135, 199, 179, $border_color); //2. ellipse
imageellipse($im, 260, 135, 198, 178, $border_color); //2. ellipse
imageellipse($im, 260, 135, 197, 177, $border_color); //2. ellipse



imagettftext ($im, 17, 0, 190, 140, $black, TTF_DIR.TTF_FONTFILE,$both); // intersection
imagettftext ($im, 17, 0, 100, 140, $black, TTF_DIR.TTF_FONTFILE,$ref); // A
imagettftext ($im, 17, 0, 270, 140, $black, TTF_DIR.TTF_FONTFILE,$comp); // A
imagettftext ($im, 17, 0, 190, 245, $black, TTF_DIR.TTF_FONTFILE,$none); // outside


imagettftext ($im, 14, 0, 140, 275, $black, TTF_DIR.TTF_FONTFILE,"Jaccard_negatome=".round($Jneg, 2));
imagettftext ($im, 14, 0, 40, 35, $black, TTF_DIR.TTF_FONTFILE,"Jaccard_interactome=".round($Jint, 2));

 imagettftext ($im, 14, 0, 100, 310, $black, TTF_DIR.TTF_FONTFILE,"binding threshold at pKd = 3.5");

header ("Content-type: image/png");
imagepng ($im);
?>
