<!DOCTYPE html>
<?php

require_once('../PDZconnect.php');
?>
<html>
	<?php
	session_start();
	?>

<style>

.centeredhalf{width:100%}
@media (min-width:1500px){.centeredhalf{width:75%}}
.centeredhalfb{width:100%}
@media (min-width:2000px){.centeredhalf{width:85%}}


.tooltip {
  position: relative;
  display: inline-block;
  color: #d3d3d3;
}

.tooltip .tooltiptext {
  visibility: hidden;
  width: 100px;
  background-color: black;
  color: #fff;
  text-align: left;
  border-radius: 6px;
  padding: 5px 5px;
  position: absolute;
  z-index: 1;
  top: 5px;
  right: 110%;
  opacity: 0;
  transition: all 1s;
}
.tooltip:hover .tooltiptext {
  visibility: visible;
  opacity: 1;
}
.tooltip .tooltiptextb {
  visibility: hidden;
  width: 200px;
  background-color: black;
  color: #fff;
  text-align: left;
  border-radius: 6px;
  padding: 5px 5px;
  position: absolute;
  z-index: 1;
  top: 5px;
  left: 110%;
  opacity: 0;
  transition: all 1s;
}
.tooltip:hover .tooltiptextb {
  visibility: visible;
  opacity: 1;
}
.w3-row-padding:after,.w3-row-padding:before{content:"";display:table;clear:both}
.w3-half{float:left;width:100%}
@media (min-width:1100px){.w3-half{width:49.9%}}

.w3-row-padding,.w3-row-padding>.w3-half{padding:0% 2.5%}


</style>
	<head>
		<title>PDZ-PBM interactome</title>
		<link rel="stylesheet" href="../assets/header-search.css">
		<script>
			var coll = document.getElementsByClassName("collapsible");
			var i;

			for (i = 0; i < coll.length; i++) {
			  coll[i].addEventListener("click", function() {
			    this.classList.toggle("active");
			    var content = this.nextElementSibling;
			    if (content.style.display === "block") {
			      content.style.display = "none";
			    } else {
			      content.style.display = "block";
			    }
			  });
			}
		</script>
	</head>

	<body style="min-width:600px;">

		<!-- THIS PART makes the connection to the mysql server -->


		<!-- THIS PART GENERATES THE MENU BAR WITH THE SEARCH FIELD -->
		<header class="header-search">
			<div class="header-limiter">
				<h1><a href="../index.php"><img src="../assets/profaff.png"  width='210' height='30' /></a></h1>
				<nav>
					<a href="PDZPBM.php">PDZ/PBM Interactome</a>
					<a href="method.php">Method</a>
					<a href="searchPBM.php" class="selectedb">Explore</a>

				</nav>







			</div>
		</header>

		<!-- THIS PART is about general info about the selected entry -->
<p></p>		



            <p>
			<?php
			
				
				$table = $_GET['searchpbm'];
				

				 if (!empty($table)) { 
				    echo "<name>Selected PBM: ".$table."</name>";;
				    #$_SESSION['carryon'] = $table; #save this into session
			    ?>
			    <!-- Get sequence (and later other info) from database -->
			    <?php	
				    #echo '"' .$table . '"'; 
				    $loadingSequence = "SELECT sequence, uniprot, peptide, REFS, DOMAINS, COMMENT from peptides WHERE PBM = '".$table."' AND STATUS = 'PUBL'";
				    $Sequenceb = $conn->query($loadingSequence);
				    //$resultSeq = mysql_fetch_array($Sequence);
				    while ($row = $Sequenceb->fetch_assoc()) {
			     		echo '<br>Uniprot: <a href=https://www.uniprot.org/uniprot/'.$row['uniprot'].'>'.$row['uniprot'].'</a><br><br>';
					$tableuniprot = $row['uniprot'];
					echo "<img src='../gdraw.php?domains=".$row['DOMAINS']."' width='400' height='125' usemap='#workmap'>";
			     		echo '<br>References: '.$row['REFS'].'</a>';
			     		echo '<br>Natural 10-mer sequence: '.$row['sequence'];
			     		echo '<br>Peptide: '.$row['peptide'];
					if (!empty($row['COMMENT'])) {
						echo '<br><b>Note:</b> '.$row['COMMENT'];
					}
					$string=$row['DOMAINS'];
	
			     		
				    }
			    ?>

		<!-- Map for links -->
		<map name="workmap">
		<?php
		$pieces = explode(";", $string);
		$scale=350/$pieces[0];
		$protein = explode("_", $table);
		$counter = 0;
		$maxdom = 0;
		$alter=0;
		// count PDZ domains
		for ($i = 1; $i <= count($pieces)-1; $i++) {
		$bits = explode("-", $pieces[$i]);
		if ($bits[2] == 1) {
			$maxdom++;
		}
		}
		for ($i = 1; $i <= count($pieces)-1; $i++) {
		$bits = explode("-", $pieces[$i]);
		if ($bits[2] == 1) {
			$counter++;
			$start = 25+($scale*$bits[0]);
			$end = 25+($scale*$bits[1]);
			if ($maxdom == 1){
			echo "<area shape='rect' coords='".$start.",10,".$end.",40' href='search_b.php?searchpdz=".$protein[0]."'>";
			} else {
			echo "<area shape='rect' coords='".$start.",10,".$end.",40' href='search_b.php?searchpdz=".$protein[0]."_".$counter."'>";
			}
		
		}


		if ($bits[2] == 0.38) {
			$counter++;
			$start = 25+($scale*$bits[0]);
			$end = 25+($scale*$bits[1]);
			echo "<area shape='rect' coords='".$start.",10,".$end.",40' href='../interactome-e6/searchmotif.php?searchmotif=".$protein[0]."'>";

		}
		if ($bits[2] == 0.36) {
			$counter++;
			$start = 25+($scale*$bits[0]);
			$end = 25+($scale*$bits[1]);
			echo "<area shape='rect' coords='".$start.",10,".$end.",40' href='../interactome-e6/searchiso.php?searchiso=".$protein[0]."'>";

		}

		if ($bits[3] == 'a') {
			$alter++;
		}
		}
		?>
		</map>
		
		<?php
		if ($alter >0) {
			echo '<br><br>Alternative motifs:<br>';
			$checklistpbm = $conn->query("SELECT PBM from peptides WHERE UNIPROT = '".$tableuniprot."' AND STATUS = 'PUBL' ORDER BY PBM");
			while($rowd = $checklistpbm->fetch_assoc()) {
				if ($rowd["PBM"] != $table){
					echo '<a href="search.php?searchpbm='.$rowd["PBM"].'">PDZome binding profile of '. $rowd["PBM"] .'</a><br>';
				}
		}




			$checklist1433 = $conn->query("SELECT MOTIF from YWHAmotifs WHERE UNIPROT = '".$tableuniprot."' AND STATUS = 'PUBL' ORDER BY MOTIF");
			while($rowg = $checklist1433->fetch_assoc()) {
					echo '<a href="../interactome-1433/searchmotif.php?searchmotif='.$rowg["MOTIF"].'">1433 binding profile of '. $rowg["MOTIF"] .'</a><br>';
				}




		}





		?>
		<br>
		<center>
		<form action="comparePBM.php" method="get">
		<label>Compare with:</label>
		<select id="PBM2" name="PBM2" required>  
			<option value="" disabled selected>Select a PBM</option> 
			<?php
			$PBMlist = $conn->query("SELECT PBM from peptides WHERE STATUS = 'PUBL' ORDER BY PBM");
			while($rowb = $PBMlist->fetch_assoc()) {
							echo "<option value=".$rowb["PBM"].">".$rowb["PBM"]."</option> ";
						  }
			?>
		</select> 
		<?php
		echo '<input type="hidden" name="PBM" value="'.$table.'" />';
		?>
		<input type="submit" value="Compare!"/>
		</form>
		</center>














		    </p>

		    <!-- separator line -->
		    <hr>

		    <!-- THIS PART is the 2 column stuff-->
<?php
$sql = "SELECT PDZ, PBM, COMP_neglogKd, source from PDZPBM WHERE PBM = '".$table."' AND COMP_neglogKd IS NOT NULL AND STATUS = 'PUBL' ORDER BY COMP_neglogKd DESC ";
$result = $conn->query($sql);
$datatoplot = array();
$peppos = array();
$pepweight = array();
$profilePDZ = array();
$profilePBM = array();
$profilepeptide_10mer = array();
$profileCOMP_neglogKd = array();
$profilesource = array();
if ($result->num_rows > 0) {
	$Nbind=0;
	while($row = $result->fetch_assoc()) {
		$profilePDZ[] = $row["PDZ"];
		$profilePBM[] = $row["PBM"];
		$profilepeptide_10mer[] = $row["peptide_10mer"];
		$profileCOMP_neglogKd[] = $row["COMP_neglogKd"];
		$profilesource[] = $row["source"];
		if($row["COMP_neglogKd"] > 3.5) {
			$Nbind++;
		}
		$datatoplot[] = $row["COMP_neglogKd"];
		}
	    $_SESSION['plotdata'] = $datatoplot; #save this into session
	    $coverage = count($datatoplot);
}
?>








		    <div class="w3-row-padding">
				    <div class="w3-half">
					    <center><img src="../plot.php?title=PDZome binding profile&xaxis=PDZ rank" class="center">
                        <?php
						echo '<br><img src="coverage.php?cover='.$coverage.'&nbind='.$Nbind.'"  class="centeredhalf"><br>';
					    echo '<a href="../dump.php?type=PBM&carryon='.$table.'" target="_blank" class="center" >Download detailed data in csv format</a></center><br>';
                        ?>
				    </div>
			    <!-- left column -->
			    <div class="w3-half">
				    <!-- left column -->
				    <!-- <button type="button" class="collapsible">Show/hide data</button> -->
				    <!-- <div class="content"> -->
					    <div style="height:600px; overflow-y:scroll; overflow-x:hidden;min-width:490px;">
					    <table>
						    <tr>
						    <th>PDZ </th>
						    <th style="text-align:left">p<i>K</i><sub>d</sub> <div class="tooltip"><img src="../assets/infow.png" width=15 length=15/>
								<span class="tooltiptextb">
								p<i>K</i><sub>d</sub> = -log<sub>10</sub>(K</i><sub>d</sub>))<br><br>
								taken from most reliable holdup method<br>
<img src=./lights/DAPF.png width=10 height=10 > > <img src=./lights/CALIP.png width=10 height=10 > > <img src=./lights/SAPF.png width=10 height=10 >
								</span>
								</div></th>
						    <th style="text-align:left">source <div class="tooltip"><img src="../assets/infow.png" width=15 length=15/>
								<span class="tooltiptext">
								<img src=./lights/FP.png width=20 height=20 > FP<br>
								<img src=./lights/DAPF.png width=20 height=20 > DAPF<br>
								<img src=./lights/CALIP.png width=20 height=20 > CALIP<br>
								<img src=./lights/SAPF.png width=20 height=20 > SAPF<br>
								</span>
								</div></th>


							    </tr>


					<?php
					$length = count($profileCOMP_neglogKd);
					for ($element = 0; $element < $length; $element++) {
						if($profileCOMP_neglogKd[$element] > 3.5) {
							echo '<tr><td><a href="search_b.php?searchpdz='.$profilePDZ[$element].'">'. $profilePDZ[$element] .'</a></td><td>'. round($profileCOMP_neglogKd[$element], 2) .'</td> <td><a href="details.php?pdz='.$profilePDZ[$element].'&pbm='.$profilePBM[$element].'"><img src=./lights/'.$profilesource[$element].'.png width=92 height=20 /></a></td>  </tr>';
						} else {
							echo '<tr><td><a href="search_b.php?searchpdz='.$profilePDZ[$element].'">'. $profilePDZ[$element] .'</a></td><td>below threshold</td><td><a href="details.php?pdz='.$profilePDZ[$element].'&pbm='.$profilePBM[$element].'"><img src=./lights/'.$profilesource[$element].'.png width=92 height=20 /></a></td></tr>';
						}
					}
					?>

						    </table>
					    </div>
				    <!-- </div> -->
			    </div>
				    <!-- right column -->

		    </div>
        <?php
        }
        $conn->close();
        ?>
<br>
<br>
<hr>
<footer style="text-align:center"><i>Please cite our work as Gogl et al., bioRxiv, 2021</i><br>
&copy; The profaff is a project of the Trave team colleciting data from the team and from a network of collaborators.</footer>

	</body>
</html>
