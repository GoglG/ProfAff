<!DOCTYPE html>
<?php

    session_destroy();
?>

<html>

<head>




	<title>14-3-3/phosphopeptide Interactome</title>

	<link rel="stylesheet" href="../assets/header-search.css">


</head>

<body>


<header class="header-search">

	<div class="header-limiter">

		<h1><a href="../index.php"><img src="../assets/profaff.png"  width='210' height='30' /></a></h1>

		<nav>
			<a href="YWHAx.php" class="selected">14-3-3/phosphopeptide Interactome</a>
			<a href="method.php">Method</a>
			<a href="search.php">Explore</a>

		</nav>



	</div>



</header>

<br>
<img src="../assets/1433.png" align="left" style="margin: 10px 20px 10px 100px;"   width='250' height='187.5' /><p style="margin: 00px 100px 00px 100px;"><name>14-3-3 proteins and their interactions</name><br>

14-3-3 proteins recognize protein partners phosphorylated at serine or threonine in certain sequence   motifs   in   all   eukaryotic   organisms.   The   seven   human   14-3-3   "isoforms", individually named beta, gamma, epsilon, zeta, eta, sigma, and tau are  distinct  gene  encoded  paralogs  which  are  highly  similar  in  sequence  and  in  their phosphopeptide-recognition mode, yet display different expression patterns across tissues.  14-3-3  proteins  are  highly  abundant  in  most  human  tissues,  where  several  14-3-3 isoforms are systematically found among the top 1% of the ~20,000 human gene-encoded proteins. 14-3-3 proteins function as dimers able to bind phosphopeptides. In our database, affinity values are shown of 14-3-3 homodimers. </p>





<br>
<br>
<hr>
<footer style="text-align:center"><i>Please cite our work as Gogl et al., bioRxiv, 2021</i><br>
&copy; The profaff is a project of the Trave team colleciting data from the team and from a network of collaborators.</footer>


</body>

</html>
