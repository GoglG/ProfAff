<?php // content="text/plain; charset=utf-8"
// Change this defines to where Your fonts are stored
DEFINE("TTF_DIR","/usr/share/fonts/truetype/dejavu/");
 
// Change this define to a font file that You know that You have
DEFINE("TTF_FONTFILE","DejaVuSerif.ttf");

$string = $_GET['domains'];
#$string="735;62-321-4;322-391-4;418-675-10;700-710-9";
;
// similar to https://www.uniprot.org/uniprot/?query=id:Q96QZ7&format=tab&columns=id,length,feature(DOMAIN EXTENT)


$pieces = explode(";", $string);

//echo $pieces[0]."<br>"; 
// length


$im = imagecreatetruecolor (800, 250);

$green = imagecolorallocate($im, 63, 113, 174);

$white = imagecolorallocate ($im, 234, 240, 242);
$black = imagecolorallocate ($im, 41, 44, 47);
$border_color = imagecolorallocate ($im, 41, 44, 47);
$gray = imagecolorallocate ($im, 191, 197, 199);


imagefilledrectangle($im,0,0,800,250,$white);
imagerectangle($im,0,0,800,250,$white);
//background


if ($pieces[0] > 2000){
	$scale=700/$pieces[0];
	imagesetthickness($im, 1);
} else {
	$scale=700/$pieces[0];
	imagesetthickness($im, 2);
}
//Here we can do some kind of dynamic scaling


imageline($im, 50, 50, 50+($scale*$pieces[0]), 50, $black);



$numdom=0;
$pdz=0;
$l27=0;
$ww=0;
$other=0;
$guk=0;
$pk=0;
$ph=0;
$pbm = 0;
$SH3 = 0;
$SH2 = 0;
$FERM = 0;
$PID = 0;
$bm1433 = 0;

if ($pieces[0] > 200){
	imagettftext ($im, 17, 0, 10, 110, $black, TTF_DIR.TTF_FONTFILE,"100 residue long scale bar:");
	imageline($im, 350, 105, 350+($scale*100), 105, $black);
} elseif ($pieces[0] > 100) {
	imagettftext ($im, 17, 0, 10, 110, $black, TTF_DIR.TTF_FONTFILE,"50 residue long scale bar:");
	imageline($im, 350, 105, 350+($scale*50), 105, $black);
} else {
	imagettftext ($im, 17, 0, 10, 110, $black, TTF_DIR.TTF_FONTFILE,"25 residue long scale bar:");
	imageline($im, 350, 105, 350+($scale*25), 105, $black);
}



imagettftext ($im, 17, 0, 10, 140, $black, TTF_DIR.TTF_FONTFILE,"Domain annotation:");




for ($i = 1; $i <= count($pieces)-1; $i++) {
	//echo $pieces[$i]."<br>"; 
	//details of domains
	$bits = explode("-", $pieces[$i]);
	//echo $bits[0]."start".$bits[1]."end".$bits[2]."type<br>";




	if ($bits[2] == 2) {
		imagefilledpolygon($im, array(50+($scale*$bits[0]), 25, 50+($scale*$bits[0]), 75, 50+($scale*$bits[1]), 50), 3, $white);
		imagepolygon($im, array(50+($scale*$bits[0]), 25, 50+($scale*$bits[0]), 75, 50+($scale*$bits[1]), 50), 3, $black);
		if ($l27 == 0) {
			$l27=1;
			imagepolygon($im, array($numdom*60+0, 155, $numdom*60+0, 205, $numdom*60+50, 180), 3, $black);
			imagettftext ($im, 16, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"L27");
			$numdom++;
		}

    	}
	//triangle forward, reserved for L27
	if ($bits[2] == 3) {
		imagefilledpolygon($im, array(50+($scale*$bits[1]), 25, 50+($scale*$bits[1]), 75, 50+($scale*$bits[0]), 50), 3, $white);
		imagepolygon($im, array(50+($scale*$bits[1]), 25, 50+($scale*$bits[1]), 75, 50+($scale*$bits[0]), 50), 3, $black);
		if ($ww == 0) {
			$ww=1;
			imagepolygon($im, array($numdom*60+50, 155, $numdom*60+50, 205, $numdom*60+0, 180), 3, $black);
			imagettftext ($im, 16, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"WW");
			$numdom++;

		}
    	}
	//triangle backward, reserved for WW


	if ($bits[2] == 4) {
		imagefilledpolygon($im, array(50+($scale*$bits[0]), 25,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),50,50+($scale*$bits[1]), 25,50+($scale*$bits[1]), 75,50+($scale*$bits[0]), 75,), 5, $white);
		imagepolygon($im, array(50+($scale*$bits[0]), 25,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),50,50+($scale*$bits[1]), 25,50+($scale*$bits[1]), 75,50+($scale*$bits[0]), 75,), 5, $black);
		if ($guk == 0) {
			$guk=1;
			imagepolygon($im, array($numdom*60, 155,$numdom*60+25,180,$numdom*60+50, 155,$numdom*60+50, 205,$numdom*60, 205), 5, $black);
			imagettftext ($im, 16, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"GUK");
			$numdom++;

		}
    	}
	//GUK

	if ($bits[2] == 5) {
		imagefilledpolygon($im, array(50+($scale*$bits[0]), 25,50+($scale*$bits[1]), 25,50+($scale*$bits[1]), 75,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),50,50+($scale*$bits[0]), 75,), 5, $white);
		imagepolygon($im, array(50+($scale*$bits[0]), 25,50+($scale*$bits[1]), 25,50+($scale*$bits[1]), 75,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),50,50+($scale*$bits[0]), 75,), 5, $black);
		if ($pk == 0) {
			$pk=1;
			imagepolygon($im, array($numdom*60, 155,$numdom*60+50, 155,$numdom*60+50, 205,$numdom*60+25,180,$numdom*60, 205), 5, $black);
			imagettftext ($im, 16, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"PKin");
			$numdom++;

		}
    	}
	//Prot.Kin.


	if ($bits[2] == 6) {
		imagefilledpolygon($im, array(50+($scale*$bits[0]), 25,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),45,50+($scale*$bits[1]), 25,50+($scale*$bits[1]), 75,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),55,50+($scale*$bits[0]), 75,), 6, $white);
		imagepolygon($im, array(50+($scale*$bits[0]), 25,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),45,50+($scale*$bits[1]), 25,50+($scale*$bits[1]), 75,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),55,50+($scale*$bits[0]), 75,), 6, $black);
		if ($ph == 0) {
			$ph=1;
			imagepolygon($im, array($numdom*60, 155,$numdom*60+25,175,$numdom*60+50, 155,$numdom*60+50, 205,$numdom*60+25,185,$numdom*60, 205), 6, $black);
			imagettftext ($im, 16, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"PH");
			$numdom++;

		}
    	}
	//PH

	if ($bits[2] == 7) {
		imagefilledpolygon($im, array(50+($scale*$bits[0]), 25,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),25,50+($scale*$bits[1]), 75,50+($scale*$bits[0]), 75), 4, $white);
		imagepolygon($im, array(50+($scale*$bits[0]), 25,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),25,50+($scale*$bits[1]), 75,50+($scale*$bits[0]), 75), 4, $black);
		if ($SH3 == 0) {
			$SH3=1;
			imagepolygon($im, array($numdom*60, 155,$numdom*60+25,155,$numdom*60+50, 205,$numdom*60, 205), 4, $black);
			imagettftext ($im, 16, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"SH3");
			$numdom++;

		}
    	}
	//SH3

	if ($bits[2] == 8) {
		imagefilledpolygon($im, array(50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),25,50+($scale*$bits[1]), 25,50+($scale*$bits[1]), 75,50+($scale*$bits[0]), 75), 4, $white);
		imagepolygon($im, array(50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),25,50+($scale*$bits[1]), 25,50+($scale*$bits[1]), 75,50+($scale*$bits[0]), 75), 4, $black);
		if ($SH2 == 0) {
			$SH2=1;
			imagepolygon($im, array($numdom*60+25,155,$numdom*60+50, 155,$numdom*60+50, 205,$numdom*60, 205), 4, $black);
			imagettftext ($im, 16, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"SH2");
			$numdom++;

		}
    	}
	//SH2

	if ($bits[2] == 9) {
		imagefilledpolygon($im, array(50+($scale*$bits[0]), 25,50+($scale*$bits[1]), 25,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),75,50+($scale*$bits[0]), 75), 4, $white);
		imagepolygon($im, array(50+($scale*$bits[0]), 25,50+($scale*$bits[1]), 25,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),75,50+($scale*$bits[0]), 75), 4, $black);
		if ($FERM == 0) {
			$FERM=1;
			imagepolygon($im, array($numdom*60, 155,$numdom*60+50,155,$numdom*60+25, 205,$numdom*60, 205), 4, $black);
			imagettftext ($im, 13, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"FERM");
			$numdom++;

		}
    	}
	//FERM

	if ($bits[2] == 10) {
		imagefilledpolygon($im, array(50+($scale*$bits[0]), 25,50+($scale*$bits[1]), 25,50+($scale*$bits[1]), 75,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),75), 4, $white);
		imagepolygon($im, array(50+($scale*$bits[0]), 25,50+($scale*$bits[1]), 25,50+($scale*$bits[1]), 75,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),75), 4, $black);
		if ($PID == 0) {
			$PID=1;
			imagepolygon($im, array($numdom*60, 155,$numdom*60+50,155,$numdom*60+50, 205,$numdom*60+25, 205), 4, $black);
			imagettftext ($im, 13, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"PID");
			$numdom++;

		}
    	}
	//PID

	if ($bits[2] > 10) {
		imagefilledrectangle($im,50+($scale*$bits[0]),25,50+($scale*$bits[1]),75,$white);
		imagerectangle($im,50+($scale*$bits[0]),25,50+($scale*$bits[1]),75,$black);
		if ($other == 0) {
			$other=1;
			imagerectangle($im,$numdom*60+0,155,$numdom*60+50,205,$black);
			imagettftext ($im, 13, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"Other");
			$numdom++;
		}
    	}
	//rectangle, reserved for other



	if ($bits[2] == 0.38) {
		imagefilledpolygon($im, array(50+($scale*$bits[0]),35,50+($scale*$bits[1]),65,50+($scale*$bits[0]),65), 3, $gray);
		//imagerectangle($im,50+($scale*$bits[0]),25,50+($scale*$bits[1]),75,$green);
		if ($bm1433 == 0) {
			$bm1433=1;
			imagefilledpolygon($im, array($numdom*60+0,165,$numdom*60+50,195,$numdom*60+0,195), 3, $gray);
			//imagefilledrectangle($im,$numdom*60+0,165,$numdom*60+50,195,$green);
			//imagerectangle($im,$numdom*60+0,155,$numdom*60+50,205,$green);
			imagettftext ($im, 12.5, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"LxxLL");
			//imagettftext ($im, 15, 0, 8+$numdom*60, 248, $black, TTF_DIR.TTF_FONTFILE,"BM");
			$numdom++;
		}
    	}
	//filled rectangle color, reserved for not selected LxxLL motif



	if ($bits[2] == 0.39) {
		imagefilledpolygon($im, array(50+($scale*$bits[0]),35,50+($scale*$bits[1]),65,50+($scale*$bits[0]),65), 3, $green);
		//imagerectangle($im,50+($scale*$bits[0]),25,50+($scale*$bits[1]),75,$green);
		if ($bm1433 == 0) {
			$bm1433=1;
			imagefilledpolygon($im, array($numdom*60+0,165,$numdom*60+50,195,$numdom*60+0,195), 3, $gray);
			//imagefilledrectangle($im,$numdom*60+0,165,$numdom*60+50,195,$green);
			//imagerectangle($im,$numdom*60+0,155,$numdom*60+50,205,$green);
			imagettftext ($im, 12.5, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"LxxLL");
			//imagettftext ($im, 15, 0, 8+$numdom*60, 248, $black, TTF_DIR.TTF_FONTFILE,"BM");
			$numdom++;
		}
    	}
	//filled rectangle color, reserved for selected LxxLL motif







	if ($bits[2] == 0.37) {
		imagefilledpolygon($im, array(50+($scale*$bits[0]), 25,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),25,50+($scale*$bits[1]), 50,50+($scale*$bits[1]), 75,50+($scale*$bits[0]), 75), 5, $green);
		imagepolygon($im, array(50+($scale*$bits[0]), 25,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),25,50+($scale*$bits[1]), 50,50+($scale*$bits[1]), 75,50+($scale*$bits[0]), 75), 5, $black);
		if ($bm1433 == 0) {
			$bm1433=1;
			imagepolygon($im, array($numdom*60, 155,$numdom*60+25,155,$numdom*60+50, 180,$numdom*60+50, 205,$numdom*60, 205), 5, $black);
			//imagerectangle($im,$numdom*60+0,155,$numdom*60+50,205,$green);
			imagettftext ($im, 15, 0, $numdom*60+12, 230, $black, TTF_DIR.TTF_FONTFILE,"E6");
			$numdom++;
		}
    	}
	//filled rectangle color, reserved for selected E6 domain




	if ($bits[2] == 0.36) {
		imagefilledpolygon($im, array(50+($scale*$bits[0]), 25,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),25,50+($scale*$bits[1]), 50,50+($scale*$bits[1]), 75,50+($scale*$bits[0]), 75), 5, $gray);
		imagepolygon($im, array(50+($scale*$bits[0]), 25,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),25,50+($scale*$bits[1]), 50,50+($scale*$bits[1]), 75,50+($scale*$bits[0]), 75), 5, $black);
		if ($bm1433 == 0) {
			$bm1433=1;
			imagepolygon($im, array($numdom*60, 155,$numdom*60+25,155,$numdom*60+50, 180,$numdom*60+50, 205,$numdom*60, 205), 5, $black);
			//imagerectangle($im,$numdom*60+0,155,$numdom*60+50,205,$green);
			imagettftext ($im, 15, 0, $numdom*60+12, 230, $black, TTF_DIR.TTF_FONTFILE,"E6");
			$numdom++;
		}
    	}
	//filled rectangle color, reserved for not selected E6 domain




	if ($bits[2] == 0.143) {
		imagefilledrectangle($im,50+($scale*$bits[0]),35,50+($scale*$bits[1]),65,$gray);
		//imagerectangle($im,50+($scale*$bits[0]),25,50+($scale*$bits[1]),75,$green);
		if ($bm1433 == 0) {
			$bm1433=1;
			imagefilledrectangle($im,$numdom*60+0,165,$numdom*60+50,195,$gray);
			//imagerectangle($im,$numdom*60+0,155,$numdom*60+50,205,$green);
			imagettftext ($im, 15, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"1433");
			imagettftext ($im, 15, 0, 8+$numdom*60, 248, $black, TTF_DIR.TTF_FONTFILE,"BM");
			$numdom++;
		}
    	}
	//filled rectangle color, reserved for not selected 1433 binding motif



	if ($bits[2] == 0.144) {
		imagefilledrectangle($im,50+($scale*$bits[0]),35,50+($scale*$bits[1]),65,$green);
		//imagerectangle($im,50+($scale*$bits[0]),25,50+($scale*$bits[1]),75,$green);
		if ($bm1433 == 0) {
			$bm1433=1;
			imagefilledrectangle($im,$numdom*60+0,165,$numdom*60+50,195,$green);
			//imagerectangle($im,$numdom*60+0,155,$numdom*60+50,205,$green);
			imagettftext ($im, 15, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"1433");
			imagettftext ($im, 15, 0, 8+$numdom*60, 248, $black, TTF_DIR.TTF_FONTFILE,"BM");
			$numdom++;
		}
    	}
	//filled rectangle color, reserved for selected 1433 binding motif

	if ($bits[2] == 0.145) {
		imagefilledrectangle($im,50+($scale*$bits[0]),35,50+($scale*$bits[1]),65,$green);
		//imagerectangle($im,50+($scale*$bits[0]),25,50+($scale*$bits[1]),75,$green);
		if ($bm1433 == 0) {
			$bm1433=1;
			imagefilledrectangle($im,$numdom*60+0,165,$numdom*60+50,195,$green);
			//imagerectangle($im,$numdom*60+0,155,$numdom*60+50,205,$green);
			imagettftext ($im, 15, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"1433");
			$numdom++;
		}
    	}
	//filled rectangle color, reserved for selected 1433 domain





	if ($bits[2] == 1) {
		imagefilledpolygon($im, array(50+($scale*$bits[0]),50,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),25,50+($scale*$bits[1]),50,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),75), 4, $gray);
		imagepolygon($im, array(50+($scale*$bits[0]),50,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),25,50+($scale*$bits[1]),50,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),75), 4, $black);
		if ($pdz == 0) {
			$pdz=1;
			imagepolygon($im, array($numdom*60+0,180,$numdom*60+25,155,$numdom*60+50,180,$numdom*60+25,205), 4, $black);
			imagettftext ($im, 16, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"PDZ");
			$numdom++;
		}
    	}
	//rombus, reserved for PDZ domain

	if ($bits[2] == 1.5) {
		imagefilledrectangle($im,50+($scale*$bits[0]),35,50+($scale*$bits[1]),65,$gray);
		//imagerectangle($im,50+($scale*$bits[0]),25,50+($scale*$bits[1]),75,$green);
		if ($pbm == 0) {
			$pbm=1;
			imagefilledrectangle($im,$numdom*60+0,165,$numdom*60+50,195,$gray);
			//imagerectangle($im,$numdom*60+0,155,$numdom*60+50,205,$green);
			imagettftext ($im, 16, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"PBM");
			$numdom++;
		}
    	}
	//filled rectangle color, reserved for selected PBM


	//Selected domains at the end!!!
	if ($bits[2] == 0) {
		imagefilledpolygon($im, array(50+($scale*$bits[0]),50,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),25,50+($scale*$bits[1]),50,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),75), 4, $green);
		imagepolygon($im, array(50+($scale*$bits[0]),50,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),25,50+($scale*$bits[1]),50,50+($scale*$bits[0])+($scale*(($bits[1]-$bits[0])/2)),75), 4, $black);
		if ($pdz == 0) {
			$pdz=1;
			imagepolygon($im, array($numdom*60+0,180,$numdom*60+25,155,$numdom*60+50,180,$numdom*60+25,205), 4, $black);
			imagettftext ($im, 16, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"PDZ");
			$numdom++;
		}
    	}
	//rombus color, reserved for selected PDZ

	if ($bits[2] == 0.5) {
		imagefilledrectangle($im,50+($scale*$bits[0]),35,50+($scale*$bits[1]),65,$green);
		//imagerectangle($im,50+($scale*$bits[0]),25,50+($scale*$bits[1]),75,$green);
		if ($pbm == 0) {
			$pbm=1;
			imagefilledrectangle($im,$numdom*60+0,165,$numdom*60+50,195,$green);
			//imagerectangle($im,$numdom*60+0,155,$numdom*60+50,205,$green);
			imagettftext ($im, 16, 0, $numdom*60, 230, $black, TTF_DIR.TTF_FONTFILE,"PBM");
			$numdom++;
		}
    	}
	//filled rectangle color, reserved for selected PBM
}





header ("Content-type: image/png");
imagepng ($im);
?>
