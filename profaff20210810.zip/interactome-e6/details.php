<!DOCTYPE html>
<?php
require_once('../PDZconnect.php');
?>
<html>
	<?php
	session_start();
	if(isset($_POST['SubmitButton'])){ //check if form was submitted
	  $input = $_POST["PBM"]; //get input text
	}    
	?>
	<head>
		<title>E6/LxxLL interactome</title>
		<link rel="stylesheet" href="../assets/header-search.css">
		<script>
			var coll = document.getElementsByClassName("collapsible");
			var i;

			for (i = 0; i < coll.length; i++) {
			  coll[i].addEventListener("click", function() {
			    this.classList.toggle("active");
			    var content = this.nextElementSibling;
			    if (content.style.display === "block") {
			      content.style.display = "none";
			    } else {
			      content.style.display = "block";
			    }
			  });
			}
		</script>
	</head>

	<body>

		<!-- THIS PART makes the connection to the mysql server -->


		<!-- THIS PART GENERATES THE MENU BAR WITH THE SEARCH FIELD -->
		<header class="header-search">
			<div class="header-limiter">
				<h1><a href="../index.php"><img src="../assets/profaff.png"  width='210' height='30' /></a></h1>
				<nav>
					<a href="YWHAx.php">E6/LxxLL interactome</a>
					<a href="method.php">Method</a>
					<a href="search.php">Explore</a>

				</nav>







			</div>
		</header>

		<!-- THIS PART is about general info about the selected entry -->
<p></p>		
<center>

<?php

$iso = $_GET["iso"]; 

$motif = $_GET["motif"]; 


$details = 'SELECT HU_BI_average, HU_BI_stdev, HU_n, HU_PEPconv, HU_pKd from E6omeLxxLLome WHERE E6 = "'.$iso.'" AND LXXLL = "'.$motif.'"  AND STATUS = "PUBL" ';

$result = $conn->query($details);

while($row = $result->fetch_assoc()) {

	echo "<b>Details of the interaction between the LxxLL motif of ".$motif." and the ".$iso." protein</b><br>";
	
	if (!empty($row['HU_pKd'])) {
	echo "<br><b>Summary of holdup measurements</b><br>";
	echo round($row['HU_n'],0)." DAPC experiments were performed<br>";





	if ($row['HU_n'] > 1){
		echo "The raw binding intensity is ". round($row['HU_BI_average'], 2)." BI with a standard deviation of ".round($row['HU_BI_stdev'], 2)." BI<br>";
	} else {
		echo "The raw binding intensity is ". round($row['HU_BI_average'], 2)." BI<br>";
	}
	echo "Peptide concentration for conversion is ".round($row['HU_PEPconv'], 1)." &micro;M<br>";
	$thresholdDAPF= round(-log10((($row['HU_PEPconv']/0.1)-4-$row['HU_PEPconv']+(0.1*4))/1000000),2);
	echo "At this peptide concentration, the detection threshold at 0.1 BI is: ".$thresholdDAPF." p<i>K</i><sub>d</sub><br>";
	if ($row['HU_pKd'] > 3.5){
		echo "Converted p<i>K</i><sub>d</sub> is ".round($row['HU_pKd'], 2)."<br>";
		$kddapf =round( 1000000*pow(10, -1*$row['HU_pKd']), 2);
		echo "Converted dissociation constant is ".$kddapf." &micro;M<br>";
		
	} else {
		echo "Binding intensity is below detection threshold (0.10 BI)<br>";
	}




	}	
}

echo '<br><br><a href="searchmotif.php?searchmotif='.$motif.'">Back to LxxLLome profile</a><br>';

echo '<a href="searchiso.php?searchiso='.$iso.'">Back to E6ome profile</a><br>';
?>

<br>
<br>
<hr>
<footer style="text-align:center"><i>Please cite our work as Gogl et al., bioRxiv, 2021</i><br>
&copy; The profaff is a project of the Trave team colleciting data from the team and from a network of collaborators.</footer>
	</body>
</html>
