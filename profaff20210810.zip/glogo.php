<?php // content="text/plain; charset=utf-8"
session_start();
//$peppos = array("LMF", "YWW", "TNQ", "GPC", "AVI", "SST", "LKD", "SST", "NDQ", "LLV");
$peppos = $_SESSION['peppos'];

$pepweight = $_SESSION['pepweight'];

//$pos = "REA";

$numpep = strlen($peppos[0]); //the same for all


$im =  imagecreatetruecolor ( 1000, 200);
$lightgray = imagecolorallocate ($im,  234, 240, 242);
imagefilledrectangle ($im,0,0,1000,200 ,$lightgray);
$empty = imagecreatefrompng('./assets/empty.png');
$Arg = imagecreatefrompng('./assets/R.png');
$Lys = imagecreatefrompng('./assets/K.png');
$His = imagecreatefrompng('./assets/H.png');
$Asp = imagecreatefrompng('./assets/D.png');
$Glu = imagecreatefrompng('./assets/E.png');
$Ser = imagecreatefrompng('./assets/S.png');
$Thr = imagecreatefrompng('./assets/T.png');
$Asn = imagecreatefrompng('./assets/N.png');
$Gln = imagecreatefrompng('./assets/Q.png');
$Gly = imagecreatefrompng('./assets/G.png');
$Pro = imagecreatefrompng('./assets/P.png');
$Cys = imagecreatefrompng('./assets/C.png');
$Ala = imagecreatefrompng('./assets/A.png');
$Val = imagecreatefrompng('./assets/V.png');
$Ile = imagecreatefrompng('./assets/I.png');
$Leu = imagecreatefrompng('./assets/L.png');
$Met = imagecreatefrompng('./assets/M.png');
$Phe = imagecreatefrompng('./assets/F.png');
$Tyr = imagecreatefrompng('./assets/Y.png');
$Trp = imagecreatefrompng('./assets/W.png');





for ($p = 0; $p <= 9; $p++) {
	$countempty=0;
	$countK=0;
	$countR=0;
	$countH=0;
	$countD=0;
	$countE=0;
	$countS=0;
	$countT=0;
	$countN=0;
	$countQ=0;
	$countG=0;
	$countC=0;
	$countP=0;
	$countA=0;
	$countV=0;
	$countI=0;
	$countL=0;
	$countM=0;
	$countF=0;
	$countY=0;
	$countW=0;
	for ($i = 0; $i <= $numpep-1; $i++) {
	    //echo $i;
	    //echo substr($pos10, $i, 1);
	    if (substr($peppos[$p], $i, 1) == "-") {
	    $countempty = $countempty + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "R") {
	    $countR = $countR + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "K") {
	    $countK = $countK + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "H") {
	    $countH = $countH + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "D") {
	    $countD = $countD + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "E") {
	    $countE = $countE + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "S") {
	    $countS = $countS + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "T") {
	    $countT = $countT + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "Q") {
	    $countQ = $countQ + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "N") {
	    $countN = $countN + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "G") {
	    $countG = $countG + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "P") {
	    $countP = $countP + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "C") {
	    $countC = $countC + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "A") {
	    $countA = $countA + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "V") {
	    $countV = $countV + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "I") {
	    $countI = $countI + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "L") {
	    $countL = $countL + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "M") {
	    $countM = $countM + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "F") {
	    $countF = $countF + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "Y") {
	    $countY = $countY + $pepweight[$p][$i];
	    }
	    if (substr($peppos[$p], $i, 1) == "W") {
	    $countW = $countW + $pepweight[$p][$i];
	    }
   	$sumweight = $countempty + $countK + $countR + $countH + $countD + $countE + $countS + $countT + $countN + $countQ + $countG + $countC + $countP + $countA + $countV + $countI + $countL + $countM + $countF + $countY + $countW;
	}
	$emptyh=($countempty / $sumweight)*200;
	$Lysh=($countK / $sumweight)*200;
	$Argh=($countR / $sumweight)*200;
	$Gluh=($countE / $sumweight)*200;
	$Hish=($countH / $sumweight)*200;
	$Asph=($countD / $sumweight)*200;
	$Serh=($countS / $sumweight)*200;
	$Thrh=($countT / $sumweight)*200;
	$Asnh=($countN / $sumweight)*200;
	$Glnh=($countQ / $sumweight)*200;
	$Glyh=($countG / $sumweight)*200;
	$Proh=($countP / $sumweight)*200;
	$Cysh=($countC / $sumweight)*200;
	$Alah=($countA / $sumweight)*200;
	$Valh=($countV / $sumweight)*200;
	$Ileh=($countI / $sumweight)*200;
	$Leuh=($countL / $sumweight)*200;
	$Meth=($countM / $sumweight)*200;
	$Pheh=($countF / $sumweight)*200;
	$Tyrh=($countY / $sumweight)*200;
	$Trph=($countW / $sumweight)*200;
	
	
	
	$Xpos=$p*100;
	$Ypos=0;
	
	
	imagecopyresampled($im, $empty, $Xpos, $Ypos, 0, 0, 100, $emptyh, 300, 300);
	$Ypos = $Ypos + $emptyh;
	
	imagecopyresampled($im, $Arg, $Xpos, $Ypos, 0, 0, 100, $Argh, 300, 300);
	$Ypos = $Ypos + $Argh;
	imagecopyresampled($im, $Lys, $Xpos, $Ypos, 0, 0, 100, $Lysh, 300, 300);
	$Ypos = $Ypos + $Lysh;
	imagecopyresampled($im, $His, $Xpos, $Ypos, 0, 0, 100, $Hish, 300, 300);
	$Ypos = $Ypos + $Hish;
	imagecopyresampled($im, $Asp, $Xpos, $Ypos, 0, 0, 100, $Asph, 300, 300);
	$Ypos = $Ypos + $Asph;
	imagecopyresampled($im, $Glu, $Xpos, $Ypos, 0, 0, 100, $Gluh, 300, 300);
	$Ypos = $Ypos + $Gluh;
	imagecopyresampled($im, $Thr, $Xpos, $Ypos, 0, 0, 100, $Thrh, 300, 300);
	$Ypos = $Ypos + $Thrh;
	imagecopyresampled($im, $Ser, $Xpos, $Ypos, 0, 0, 100, $Serh, 300, 300);
	$Ypos = $Ypos + $Serh;
	imagecopyresampled($im, $Asn, $Xpos, $Ypos, 0, 0, 100, $Asnh, 300, 300);
	$Ypos = $Ypos + $Asnh;
	imagecopyresampled($im, $Gln, $Xpos, $Ypos, 0, 0, 100, $Glnh, 300, 300);
	$Ypos = $Ypos + $Glnh;
	imagecopyresampled($im, $Gly, $Xpos, $Ypos, 0, 0, 100, $Glyh, 300, 300);
	$Ypos = $Ypos + $Glyh;
	imagecopyresampled($im, $Pro, $Xpos, $Ypos, 0, 0, 100, $Proh, 300, 300);
	$Ypos = $Ypos + $Proh;
	imagecopyresampled($im, $Cys, $Xpos, $Ypos, 0, 0, 100, $Cysh, 300, 300);
	$Ypos = $Ypos + $Cysh;
	imagecopyresampled($im, $Ala, $Xpos, $Ypos, 0, 0, 100, $Alah, 300, 300);
	$Ypos = $Ypos + $Alah;
	imagecopyresampled($im, $Val, $Xpos, $Ypos, 0, 0, 100, $Valh, 300, 300);
	$Ypos = $Ypos + $Valh;
	imagecopyresampled($im, $Ile, $Xpos, $Ypos, 0, 0, 100, $Ileh, 300, 300);
	$Ypos = $Ypos + $Ileh;
	imagecopyresampled($im, $Leu, $Xpos, $Ypos, 0, 0, 100, $Leuh, 300, 300);
	$Ypos = $Ypos + $Leuh;
	imagecopyresampled($im, $Met, $Xpos, $Ypos, 0, 0, 100, $Meth, 300, 300);
	$Ypos = $Ypos + $Meth;
	imagecopyresampled($im, $Phe, $Xpos, $Ypos, 0, 0, 100, $Pheh, 300, 300);
	$Ypos = $Ypos + $Pheh;
	imagecopyresampled($im, $Tyr, $Xpos, $Ypos, 0, 0, 100, $Tyrh, 300, 300);
	$Ypos = $Ypos + $Tyrh;
	imagecopyresampled($im, $Trp, $Xpos, $Ypos, 0, 0, 100, $Trph, 300, 300);
}









header ("Content-type: image/png");
imagepng ($im);
imagedestroy($png);
imagedestroy($im);
imagedestroy($empty);
imagedestroy($Arg);
imagedestroy($Lys);
imagedestroy($Glu);
imagedestroy($His);
imagedestroy($Asp);
imagedestroy($Ser);
imagedestroy($Thr);
imagedestroy($Asn);
imagedestroy($Gln);
imagedestroy($Cys);
imagedestroy($Pro);
imagedestroy($Gly);
imagedestroy($Ala);
imagedestroy($Ile);
imagedestroy($Leu);
imagedestroy($Val);
imagedestroy($Phe);
imagedestroy($Tyr);
imagedestroy($Trp);
imagedestroy($Met);

session_close();
?>
