<!DOCTYPE html>
<html>
<?php
session_start();
session_destroy();
require_once('./PDZconnect.php');
?>
<style>

.centeredhalf{width:50%}
@media (min-width:1000px){.centeredhalf{width:65%}}


.w3-row-padding:after,.w3-row-padding:before{content:"";display:table;clear:both}
.w3-third{float:left;width:100%}
@media (min-width:1000px){.w3-third{width:33.33333%}}
.w3-row-padding,.w3-row-padding>.w3-half{padding:0% 2.5%}

toc {
	padding-left: 10%;
	float: left;
	font-size: 120%
}

</style>
<head>




	<title>PROFAFF</title>

	<link rel="stylesheet" href="assets/header-search.css">


</head>

<body>


<header class="header-search">

	<div class="header-limiter">

		<h1><img src="assets/profaff.png"  width='210' height='30' /></h1>

		<nav>
			




	</div>



</header>

<p>Welcome to the first open release of our interactomic database!<br>
Our goal is to <b>PROF</b>ile interactomes of domain-motif networks with exact <b>AFF</b>inities using well-defined interaction fragments and quantitative methods.<br>
<br>
<i>Last update on 23/07/2021<br>
Major changes:<br>
-We are now open and online!<br>
</i></p>

<hr>

<center>

<div class="w3-row-padding">
<div class="w3-third">

<a href="interactome-pdz/PDZPBM.php"><img src="assets/pdz.png"  class="centeredhalf" /> <p><b>PDZ/PBM interactome</b><br>
<?php
$countPDZ = $conn->query("select count(COMP_neglogkd) as total from PDZPBM WHERE STATUS = 'PUBL';");
while($count = $countPDZ->fetch_assoc()) {
							echo 'with '. $count[total].' interactions';
						  }			
?>
</p></a>

</div>
<div class="w3-third">
<a href="interactome-1433/YWHAx.php"><img src="assets/1433.png"  class="centeredhalf" /> <p><b>14-3-3/phosphopeptide interactome</b><br>
<?php
$countPDZ = $conn->query("select count(FP_aver_uM) as total from YWHAdata WHERE STATUS = 'PUBL';");
while($count = $countPDZ->fetch_assoc()) {
							echo 'with '. $count[total].' interactions';
						  }			
?>

</p></a>
</div>

<div class="w3-third">
<a href="interactome-e6/YWHAx.php"><img src="assets/lxxll.png"  class="centeredhalf" /> <p><b>HPV-E6/LxxLL interactome</b><br>
<?php
$countPDZ = $conn->query("select count(HU_pKd) as total from E6omeLxxLLome WHERE STATUS = 'PUBL';");
while($count = $countPDZ->fetch_assoc()) {
							echo 'with '. $count[total].' interactions';
						  }			
?>
</p></a>
</div>
</div>

</center>



<br>
<br>
<hr>
<footer style="text-align:center"><i>Please cite our work as Gogl et al., bioRxiv, 2021</i><br>
&copy; The profaff is a project of the Trave team colleciting data from the team and from a network of collaborators.</footer>




</body>

</html>
