<?php
require_once('./PDZconnect.php');


$table = $_GET['carryon'];
$type = $_GET['type'];

if ($type == 'ALL'){
$sqlfull = 'SELECT * from PDZPBM WHERE STATUS = "PUBL"';
} else {
$sqlfull = 'SELECT * from PDZPBM WHERE '.$type.' = "'.$table.'" AND STATUS = "PUBL"';
}

$full = $conn->query($sqlfull);
$number_of_fields = mysqli_num_fields($full);
$headers = array();
for ($i = 0; $i < $number_of_fields; $i++) {
    $headers[] = mysqli_field_name($full , $i);
}
$fp = fopen('php://output', 'w');
if ($fp && $full) {
    header('Content-Type: text/csv');

    if ($type == 'ALL'){
    header('Content-Disposition: attachment; filename="profaff.csv"');
    } else {
    header('Content-Disposition: attachment; filename="'.$table.'.csv"');
    }

    header('Pragma: no-cache');
    header('Expires: 0');
    fputcsv($fp, $headers);
    while ($row = $full->fetch_array(MYSQLI_NUM)) {
        fputcsv($fp, array_values($row));
    }
    die;
}

function mysqli_field_name($full, $field_offset)
{
    $properties = mysqli_fetch_field_direct($full, $field_offset);
    return is_object($properties) ? $properties->name : null;
}
$conn->close();
?>
