<!DOCTYPE html>
<?php

require_once('../PDZconnect.php');
?>
<html>
	<?php
	session_start();
	?>
	
	<style>
.w3-row-padding:after,.w3-row-padding:before{content:"";display:table;clear:both}
.w3-half{float:left;width:100%}
@media (min-width:1100px){.w3-half{width:49.9%}}

.w3-row-padding,.w3-row-padding>.w3-half{padding:0% 2.5%}


</style>
	<head>
		<title>14-3-3/phosphopeptide Interactome</title>
		<link rel="stylesheet" href="../assets/header-search.css">
		<script>
			var coll = document.getElementsByClassName("collapsible");
			var i;

			for (i = 0; i < coll.length; i++) {
			  coll[i].addEventListener("click", function() {
			    this.classList.toggle("active");
			    var content = this.nextElementSibling;
			    if (content.style.display === "block") {
			      content.style.display = "none";
			    } else {
			      content.style.display = "block";
			    }
			  });
			}
		</script>
	</head>

	<body>

		<!-- THIS PART makes the connection to the mysql server -->


		<!-- THIS PART GENERATES THE MENU BAR WITH THE SEARCH FIELD -->
		<header class="header-search">
			<div class="header-limiter">
				<h1><a href="../index.php"><img src="../assets/profaff.png"  width='210' height='30' /></a></h1>
				<nav>
					<a href="YWHAx.php">14-3-3/phosphopeptide Interactome</a>
					<a href="method.php">Method</a>
					<a href="search.php" class="selectedb">Explore</a>

				</nav>







			</div>
		</header>

		<!-- THIS PART is about general info about the selected entry -->
<p></p>		



            <p>
			<?php
			
				
				$table = $_GET['searchmotif'];
				

				 if (!empty($table)) { 
				    echo "<name>Selected 14-3-3 binding motif: ".$table."</name>";;
				    #$_SESSION['carryon'] = $table; #save this into session
			    ?>
			    <!-- Get sequence (and later other info) from database -->
			    <?php	
				    #echo '"' .$table . '"'; 
				    $loadingSequence = "SELECT sequence, uniprot, peptide, REFS, DOMAINS from YWHAmotifs WHERE MOTIF = '".$table."' AND STATUS = 'PUBL'";
				    $Sequenceb = $conn->query($loadingSequence);
				    //$resultSeq = mysql_fetch_array($Sequence);
				    while ($row = $Sequenceb->fetch_assoc()) {
			     		echo '<br>Uniprot: <a href=https://www.uniprot.org/uniprot/'.$row['uniprot'].'>'.$row['uniprot'].'</a><br><br>';
					$tableuniprot = $row['uniprot'];
					echo "<img src='../gdraw.php?domains=".$row['DOMAINS']."' width='400' height='125' usemap='#workmap'>";
			     		echo '<br>References: '.$row['REFS'].'</a>';
			     		echo '<br>14-3-3 bindin motif: '.$row['sequence'];
			     		echo '<br>Peptide: '.$row['peptide'];
					$string=$row['DOMAINS'];
	
			     		
				    }
			    ?>

		<!-- Map for links -->
		<map name="workmap">
		<?php
		$pieces = explode(";", $string);
		$scale=350/$pieces[0];
		$protein = explode("_", $table);
		$counter = 0;
		$maxdom = 0;
		$alter=0;
		// count PDZ domains
		for ($i = 1; $i <= count($pieces)-1; $i++) {
		$bits = explode("-", $pieces[$i]);
		if ($bits[2] == 1) {
			$maxdom++;
		}
		}
		for ($i = 1; $i <= count($pieces)-1; $i++) {
		$bits = explode("-", $pieces[$i]);
		if ($bits[2] == 1) {
			$counter++;
			$start = 25+($scale*$bits[0]);
			$end = 25+($scale*$bits[1]);
			if ($maxdom == 1){
			echo "<area shape='rect' coords='".$start.",10,".$end.",40' href='search_b.php?searchpdz=".$protein[0]."'>";
			} else {
			echo "<area shape='rect' coords='".$start.",10,".$end.",40' href='search_b.php?searchpdz=".$protein[0]."_".$counter."'>";
			}
		
		}
		if ($bits[2] == 0.36) {
			$counter++;
			$start = 25+($scale*$bits[0]);
			$end = 25+($scale*$bits[1]);
			echo "<area shape='rect' coords='".$start.",10,".$end.",40' href='../interactome-e6/searchiso.php?searchiso=".$protein[0]."'>";

		}
		if ($bits[3] == 'a') {
			$alter++;
		}
		}
		?>
		</map>
		
		<?php
		if ($alter >0) {
			echo '<br><br>Alternative motifs:<br>';
			$checklistpbm = $conn->query("SELECT PBM from peptides WHERE UNIPROT = '".$tableuniprot."' AND STATUS = 'PUBL' ORDER BY PBM");
			while($rowd = $checklistpbm->fetch_assoc()) {
				echo '<a href="../interactome-pdz/search.php?searchpbm='.$rowd["PBM"].'">PDZome binding profile of '. $rowd["PBM"] .'</a><br>';


		}

			$checklist1433 = $conn->query("SELECT MOTIF from YWHAmotifs WHERE UNIPROT = '".$tableuniprot."' AND STATUS = 'PUBL' ORDER BY MOTIF");
			while($rowg = $checklist1433->fetch_assoc()) {
					if ($rowg["MOTIF"] != $table){
					echo '<a href="../interactome-1433/searchmotif.php?searchmotif='.$rowg["MOTIF"].'">1433 binding profile of '. $rowg["MOTIF"] .'</a><br>';
					}
				}



		}

		?>




		    </p>

		    <!-- separator line -->
		    <hr>

		    <!-- THIS PART is the 2 column stuff-->




		    <div class="w3-row-padding">
			    <!-- left column -->
			    <div class="w3-half">
				    <!-- left column -->
				    <!-- <button type="button" class="collapsible">Show/hide data</button> -->
				    <!-- <div class="content"> -->

					    <table>
						    <tr>
						    <th>14-3-3 isoform </th>
						    <th style="text-align:left">p<i>K</i><sub>d</sub></th>
						    <th style="text-align:left">method </th>

					   
							    </tr>
							    <?php
								    $sql = "SELECT ISO, MOTIF, FP_aver_uM, FP_MODE from YWHAdata WHERE MOTIF = '".$table."' AND FP_aver_uM IS NOT NULL AND STATUS = 'PUBL' ORDER BY FP_aver_uM ASC ";
								    $result = $conn->query($sql);
								    $datatoplot = array();
								    if ($result->num_rows > 0) {
									    while($row = $result->fetch_assoc()) {
										$pKd = -1*(log10($row["FP_aver_uM"]/1000000));
										

									    if($pKd > 3.6) {
									    
                                            						echo '<tr><td><a href="searchiso.php?searchiso='.$row["ISO"].'">14-3-3&'. $row["ISO"] .'; ('.$row["ISO"].')</a></td><td>'. round($pKd, 2) .'</td> <td><a href="details.php?iso='.$row["ISO"].'&motif='.$row["MOTIF"].'">'. $row["FP_MODE"] .'</a></td>  </tr>';
											$datatoplot[] = $pKd;
											} else {
											echo '<tr><td><a href="searchiso.php?searchiso='.$row["ISO"].'">14-3-3&'. $row["ISO"] .'; ('.$row["ISO"].')</a></td><td>< 3.6</td> <td><a href="details.php?iso='.$row["ISO"].'&motif='.$row["MOTIF"].'">'. $row["FP_MODE"] .'</a></td>  </tr>';
											$datatoplot[] = 0;											

									     }
								    }
								    } else {
									    echo "0 results";
								    }
								    $_SESSION['plotdata'] = $datatoplot;
							    ?>
						    </table>
					    
				    <!-- </div> -->
			    </div>
				    <!-- right column -->
				    <div class="w3-half">
					<img src="../plot.php?title=14-3-3ome binding profile&xaxis=14-3-3 rank" class="center">
				    </div>
		    </div>
        <?php
        }
        $conn->close();
        ?>
<br>
<br>
<hr>
<footer style="text-align:center"><i>Please cite our work as Gogl et al., bioRxiv, 2021</i><br>
&copy; The profaff is a project of the Trave team colleciting data from the team and from a network of collaborators.</footer>

	</body>
</html>
