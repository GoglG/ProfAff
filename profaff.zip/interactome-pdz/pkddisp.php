<?php // content="text/plain; charset=utf-8"
session_start();
require_once ('../jpgraph/jpgraph.php');
require_once ('../jpgraph/jpgraph_bar.php');
require_once ('../jpgraph/jpgraph_plotline.php');

$datay=$_SESSION['pkds'];
$label=$_SESSION['methods'];
$threshold=$_SESSION['average'];





$xaxis = "method";
$title = "measured pKd values";

// Create the graph. These two calls are always required
$graph = new Graph(800,200,'auto');
$graph->SetScale("textlin",3.5,7);

#$theme_class=new UniversalTheme;
#$graph->SetTheme($theme_class);

#$graph->yaxis->SetTickPositions(array(0,30,60,90,120,150), array(15,45,75,105,135));
$graph->SetBox(false);

$graph->ygrid->SetFill(false);

$graph->yaxis->HideLine(false);
$graph->yaxis->HideTicks(false,false);




$t_plot = new PlotLine();
$t_plot->SetLineStyle('solid'); 
$t_plot->SetWeight(2);
$t_plot->SetDirection(horizontal);
$t_plot->SetColor('#608bd2');
$t_plot->SetPosition($threshold);

$graph->AddLine($t_plot);




#$graph->yaxis->SetFillColor('#eaf0f2');

// Create the bar plots
$b1plot = new BarPlot($datay);

// ...and add it to the graPH
$graph->Add($b1plot);

$graph->SetColor('#eaf0f2');
$graph->SetMarginColor("#eaf0f2");
$graph->SetFrame(true,'#eaf0f2',1);
$graph->xaxis->SetTickLabels($label);


$b1plot->SetColor("#292c2f");
$b1plot->SetFillColor("#292c2f");

$b1plot->SetWidth(0.5);





$graph->title->Set($title);
$graph->xaxis->title->Set($xaxis);
$graph->yaxis->title->Set("pKd");

$graph->xaxis->SetPos('min');
$graph->SetMargin(80,20,50,20);
$graph->yaxis->SetTitleMargin(50);



// Display the graph
$graph->Stroke();
session_close();
?>
