<!DOCTYPE html>
<?php
    session_destroy();
?>

<html>

<head>




	<title>E6/LxxLL interactome</title>

	<link rel="stylesheet" href="../assets/header-search.css">


</head>

<body>


<header class="header-search">

	<div class="header-limiter">

		<h1><a href="../index.php"><img src="../assets/profaff.png"  width='210' height='30' /></a></h1>

		<nav>
			<a href="YWHAx.php" class="selected">E6/LxxLL interactome</a>
			<a href="method.php">Method</a>
			<a href="search.php">Explore</a>

		</nav>



	</div>



</header>

<br>
<p style="margin: 00px 200px 00px 200px;"><name>Human Papillomaviruses</name><br>
Human Papillomaviruses (HPV) are small DNA viruses infecting epithelia. More than 200 HPV types have been identified <a href=https://pave.niaid.nih.gov/>to date</a>. They differ by their tropism (cutaneous/mucosal) and by their oncogenic risk. While the so-called “low-risk” HPVs only cause benign proliferations (warts, condylomas), the high-risk HPVs are at the origin of various cancers: cervix, head and neck, skin, anus… Cervix cancer is essentially caused by oncogenic HPVs, in particular HPV16 and 18, which account for 61 % and 11 % of the cases, respectively (Serrano et al., 2015). In addition, an increasing number of head and neck cancers (oropharynx, oral cavity and larynx) are associated with  HPV  infection.  Of  these  HPV-positive  cancers,  71%  are  attributed  to  HPV16 (Castellsagué et al., 2016). </p>
<br>
<p style="margin: 00px 200px 00px 200px;"><name>E6 proteins</name><br>
The virus encodes two oncoproteins named E6 and E7, which trigger viral replication by stimulating cellular proliferation. E6 disrupts the function of many cellular proteins by protein-motif interactions. On the one hand, some E6 is equipped with a C-terminal <a href=../interactome-pdz/PDZPBM.php>PDZ-binding motif</a>. On the other hand, the two zinc-binding domains of E6 form a hydrophobic pocket which binds to peptide motif of consensus “LxxLL”. A wide variety of cellular proteins harbor such motifs, for instance the E3 ubiquitin ligase E6AP. E6 from HPV16 binds an LxxLL motif located within E6AP (Huibregtse et al. 1993). Once this heterodimer is formed, it recruits the tumor suppressor p53 by its core domain. This complex induces p53 ubiquitinylation, which leads p53 to its proteasomal degradation. 

Each  E6  protein, produced  by  a  given  HPV  type,  targets  a  certain  set  of  host  proteins,  and  these interaction preferences contribute to the variability of pathological effects caused by the virus. We explored the interaction preferences of E6 proteins from distinct HPV types for a peptide library entailing putative or published LxxLL target peptides. </p>


<hr>

<br>
<center><name>Key references</name></center>
<p style="margin: 00px 200px 00px 200px;">
-Human papillomavirus genotype attribution for HPVs 6, 11, 16, 18, 31, 33, 45, 52 and 58 in female anogenital lesions. <i>B Serrano et al. European Journal of Cancer, 2015</i><br>
-HPV Involvement in Head and Neck Cancers: Comprehensive Assessment of Biomarkers in 3680 Patients. <i>X Castellsague, J Natl Cancer Inst, 2016</i><br>
-Structure of the E6/E6AP/p53 complex required for HPV-mediated degradation of p53. <i>D Martinez-Zapien et al. Nature, 2016</i><br>

-Structural Basis for Hijacking of Cellular LxxLL Motifs by Papillomavirus E6 Oncoproteins. <i>K Zanier et al. Science, 2013</i>
</p>


<br>
<br>
<hr>
<footer style="text-align:center"><i>Please cite our work as Gogl et al., bioRxiv, 2021</i><br>
&copy; The profaff is a project of the Trave team colleciting data from the team and from a network of collaborators.</footer>


</body>

</html>
