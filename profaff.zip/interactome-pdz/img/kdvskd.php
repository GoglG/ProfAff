<?php // content="text/plain; charset=utf-8"
require_once ('../../jpgraph/jpgraph.php');
require_once ('../../jpgraph/jpgraph_scatter.php');

require_once('../../PDZconnect.php');

$datax = array();
$datay = array();
$data = $conn->query("SELECT FP_aver_uM, COMP_neglogKd from PDZPBM WHERE COMP_neglogKd IS NOT NULL AND FP_aver_uM IS NOT NULL");
while ($row = $data->fetch_assoc()) {
			if (($row['COMP_neglogKd'] > 3.5)&&($row['COMP_neglogKd'] < 6.5)&&($row['FP_aver_uM'] < 316)&&($row['FP_aver_uM'] > 0.3)){
	 		$datax[] = -log10(($row['FP_aver_uM'])/1000000);
	 		$datay[] = $row['COMP_neglogKd'];
			}
}
			     		
			     		
			     		
			     		

$graph = new Graph(300,300);






$graph->SetScale("lin",3.5,6.5, 3.5, 6.5);
$graph->img->SetMargin(70,20,20,70);        
$graph->SetBox(false);
 $graph->ygrid->SetFill(false);
 $graph->yaxis->HideLine(false);
 $graph->xgrid->Show(true);                  
$graph->ygrid->Show(true); 


$graph->title->Set("FP vs. composite holdup");
$graph->title->SetFont(FF_FONT1,FS_BOLD,11);
$graph->title->SetColor('#292c2f');


$graph->xaxis->title->Set("pKd from FP");
$graph->xaxis->title->SetMargin(20);
$graph->xaxis->title->SetFont(FF_FONT1,FS_BOLD,20);

$graph->SetColor('#eaf0f2');
$graph->SetMarginColor("#eaf0f2");
$graph->SetFrame(true,'#eaf0f2',1);

$graph->yaxis->title->Set("pKd from holdup");
$graph->yaxis->title->SetMargin(20);
$graph->yaxis->title->SetFont(FF_FONT1,FS_BOLD,20);

$sp1 = new ScatterPlot($datay,$datax);
$sp1->mark->SetFillColor("#292c2f");


$graph->Add($sp1);



$graph->Stroke();
 session_destroy();
?>
