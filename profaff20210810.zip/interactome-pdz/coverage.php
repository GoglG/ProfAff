<?php // content="text/plain; charset=utf-8"
require_once ('../jpgraph/jpgraph.php');
require_once ('../jpgraph/jpgraph_pie.php');
require_once ('../jpgraph/jpgraph_pie3d.php');

$coverage = $_GET['cover'];
$nbind = $_GET['nbind'];
$rest = 266-$coverage;
$negatome = $coverage-$nbind;

// Some data
$data = array($nbind,$negatome,$rest);
$legend = array('detectably binds', 'binding not detected', 'not measured');
// Create the Pie Graph. 
$graph = new PieGraph(600,250);
// Set A title for the plot
$graph->title->Set("Experimental coverage of the human PDZome");
$graph->legend->SetPos(0.5,0.99999,'center','bottom');
$graph->legend->SetColor('black');
$graph->legend->SetFillColor('#eaf0f2');
$graph->title->SetColor('black');

$graph->SetColor('#eaf0f2');
// Create
$p1 = new PiePlot3D($data);
$graph->Add($p1);

$p1->SetLegends($legend); //Set the legend 


$p1->SetSliceColors(array('#3F71AE', '#bfc5c7','#F5F5F5'));
$p1->value->SetColor('black');
$p1->ShowBorder();
$p1->SetColor('black');
$p1->ExplodeSlice(0);
$graph->Stroke();

?>
