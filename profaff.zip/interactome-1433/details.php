<!DOCTYPE html>
<?php
require_once('../PDZconnect.php');
?>
<html>
	<?php
	session_start();
	if(isset($_POST['SubmitButton'])){ //check if form was submitted
	  $input = $_POST["PBM"]; //get input text
	}    
	?>
	<head>
		<title>14-3-3/phosphopeptide Interactome</title>
		<link rel="stylesheet" href="../assets/header-search.css">
		<script>
			var coll = document.getElementsByClassName("collapsible");
			var i;

			for (i = 0; i < coll.length; i++) {
			  coll[i].addEventListener("click", function() {
			    this.classList.toggle("active");
			    var content = this.nextElementSibling;
			    if (content.style.display === "block") {
			      content.style.display = "none";
			    } else {
			      content.style.display = "block";
			    }
			  });
			}
		</script>
	</head>

	<body>

		<!-- THIS PART makes the connection to the mysql server -->


		<!-- THIS PART GENERATES THE MENU BAR WITH THE SEARCH FIELD -->
		<header class="header-search">
			<div class="header-limiter">
				<h1><a href="../index.php"><img src="../assets/profaff.png"  width='210' height='30' /></a></h1>
				<nav>
					<a href="YWHAx.php">14-3-3/phosphopeptide Interactome</a>
					<a href="method.php">Method</a>
					<a href="search.php">Explore</a>

				</nav>







			</div>
		</header>

		<!-- THIS PART is about general info about the selected entry -->
<p></p>		
<center>

<?php

$iso = $_GET["iso"]; 

$motif = $_GET["motif"]; 


$details = 'SELECT FP_aver_uM, FP_stdev_uM, FP_MODE from YWHAdata WHERE ISO = "'.$iso.'" AND MOTIF = "'.$motif.'"  AND STATUS = "PUBL" ';

$result = $conn->query($details);

while($row = $result->fetch_assoc()) {

	echo "<b>Details of the interaction between the motif of ".$motif." and the ".$iso." 14-3-3 protein</b><br>";
	
	if (!empty($row['FP_aver_uM'])) {
	echo "<br><b>Summary of Fluorescent polarization assay</b><br>";
	echo "The dissociation constand deduced from FP is ". round($row['FP_aver_uM'], 4)." &micro;M with a standard deviation of ".round($row['FP_stdev_uM'], 4)." &micro;M<br>";
	echo "FP was performed in triplicates.<br>";
	if ($row['FP_MODE'] == "COMP") {
	echo "The data is a result of a competitive FP measurement";	
	}
	if ($row['FP_MODE'] == "DIRE") {
	echo "The data is a result of a direct FP measurement";	
	}

	} else {
	echo "<br><b>No FP measurement is available.</b> <br>";
	}	
}

echo '<br><br><a href="searchmotif.php?searchmotif='.$motif.'">Back to 14-3-3 binding motif profile</a><br>';

echo '<a href="searchiso.php?searchiso='.$iso.'">Back to 14-3-3 isoform profile</a><br>';
?>

<br>
<br>
<hr>
<footer style="text-align:center"><i>Please cite our work as Gogl et al., bioRxiv, 2021</i><br>
&copy; The profaff is a project of the Trave team colleciting data from the team and from a network of collaborators.</footer>
	</body>
</html>
